"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:test.py
@Created Time: 2023.05.15
"""
import copy
import math
from itertools import combinations_with_replacement
import numpy as np


def gen_init_solution(worker_list, simulation_task_list, pop_size):
    worker_num = len(worker_list)

    init_res_solution = []
    for _ in range(pop_size):
        task_group = [[] for _ in range(worker_num)]
        temp_task_list = copy.deepcopy(simulation_task_list)
        while len(temp_task_list) > 0:
            # 随机选一个计算节点的下标
            worker_index = np.random.randint(low=0, high=worker_num)
            # 随机选一个计算任务的下标
            task_num = len(temp_task_list)
            task_index = np.random.randint(low=0, high=task_num)
            task_group[worker_index].append(temp_task_list[task_index])
            del temp_task_list[task_index]
        init_res_solution.append(task_group)
    return np.array(init_res_solution)


def gen_init_solution_new(worker_dict: dict, simulation_task_dict: dict, pop_size: int):
    row_num = pop_size
    worker_num = len(worker_dict)
    task_num = len(simulation_task_dict)
    col_num = task_num + worker_num
    res_solution = np.zeros(shape=(row_num, col_num))
    for i in range(0, row_num):
        task_id_list = list(simulation_task_dict.keys())
        for j in range(0, task_num):
            pop_task_id = np.random.choice(task_id_list, replace=False)
            res_solution[i, j] = pop_task_id
            task_id_list.remove(pop_task_id)
        surplus_task = copy.deepcopy(task_num)
        for j in range(task_num, col_num):
            if j == col_num - 1:
                # 以保证 sum(res[i,task_num:col_num-1]) == task_num
                res_solution[i, col_num - 1] = surplus_task
                break
            allocation_num = np.random.randint(0, surplus_task)
            res_solution[i, j] = allocation_num
            surplus_task -= allocation_num

    return res_solution


def calc_fitness(x: np.ndarray):
    pass


def allocation_method_update(task_num, worker_num, pop_size, x: np.ndarray):
    """
        更新服务器分配方式,将最大值变小，最小值变大
    :param x: (pop size,num of tasks + num of servers)
    :return:
    """
    res_x = x
    for i in range(0, pop_size):
        alpha = np.random.rand()
        if alpha > 0.3:
            max_index = np.argmax(x[i, task_num:])
            min_index = np.argmin(x[i, task_num:])
            res_x[i, task_num + max_index] -= 1
            res_x[i, task_num + min_index] += 1
    return res_x


def __decode_to_discrete(discrete_x_old: np.ndarray, continuous_x_old, simulation_task_dict, n_dim):
    """
        应用DSSA中的离散方式将经过函数运算后的连续值映射回离散值
    :param discrete_x_old:
    :param continuous_x_old:
    :return:
    """
    assert discrete_x_old.shape == continuous_x_old.shape

    task_num = len(simulation_task_dict)
    row_n = continuous_x_old.shape[0]
    res_x = np.zeros((row_n, n_dim))

    sorted_discrete_x_old = np.sort(discrete_x_old[:, :task_num], axis=1)
    sorted_continuous_x = np.sort(continuous_x_old[:, :task_num], axis=1)

    for i in range(0, row_n):
        for j in range(0, task_num):
            """
            假设连续解为 [1.2, 3, 1.2, 3]
            排序后为    [1.2, 1.2, 3, 3]
            最终的离散化映射结果如果不增加vis,会变成[1,3,1,3]
            增加vis后会变为[1,3,2,4],所以我们需要vis数组保证映射的独立性
            """
            vis = np.full(shape=(1, task_num), fill_value=False)
            target = sorted_continuous_x[i, j]

            for jj in range(0, task_num):
                print(
                    "i:{}, target:{},\nsorted_continuous_x[i]:{},\ncontinuous_x_old[i]:{},sorted_continuous_x[i, {}]={}".format(
                        i, target,
                        sorted_continuous_x[i, 0:task_num],
                        continuous_x_old[i, 0:task_num],
                        jj, sorted_continuous_x[i, jj]))

                if (math.isclose(continuous_x_old[i, jj], target)) and (vis[0, jj] is False):
                    res_x[i, j] = sorted_discrete_x_old[i, jj]
                    vis[0, jj] = True

            for jj in range(task_num, n_dim):
                res_x[i, jj] = discrete_x_old[i, jj]

    return res_x


if __name__ == '__main__':
    # POP_SIZE = 50
    # w_d = {1: 84.8290447359484, 2: 74.74604932817718, 3: 74.50033209903846}
    # t_d = {1: [45, 49, 3], 2: [34, 63, 1], 3: [72, 86, 0], 4: [88, 109, 2], 5: [7, 6, 1], 6: [47, 51, 2],
    #        7: [38, 49, 3],
    #        8: [58, 70, 2], 9: [22, 29, 0], 10: [66, 112, 1]}
    # s = gen_init_solution_new(worker_dict=w_d, simulation_task_dict=t_d, pop_size=POP_SIZE)
    # print(s[0:5, :])
    # s = allocation_method_update(len(t_d), len(w_d), POP_SIZE, s)
    # print("After allocation method update")
    # print(s[0:5, :])
    # # print(s.shape)
    # # for i in range(0, s.shape[0]):
    # #     for j in range(0, len(t_d)):
    # #         print(s[i, j], end=",")
    # #     for j in range(len(t_d), len(t_d) + len(w_d)):
    # #         if j == len(t_d):
    # #             print(" | {},".format(s[i, j]),end="")
    # #         else:
    # #             print("{},".format(s[i, j]), end="")
    # #     print()
    #
    # print(np.std([0, 2, 3]))
    # print(np.std([2, 1, 1]))

    import numpy as np

    arr = np.array(
        [47.5, 8.8, 64.6, 9.3, 40.7, 49.8, 14.4, 33.3, 20.2, 23.3, 25.2, 47.2, 19.9, 18.6, 39.8, 36.2, 20., 63.7, 24.2,
         33.8, 23.7, 49.5, 10.1, 63.9, 24.1, 11., 39.2, 31.8, 55.1, 36.1, 15.5, 7.5, 36.3, 58.7, 25., 52.7, 7.3, 34.,
         18.3, 33.1, 49.8, 13.7, 23.8, 44.5, 42.3, 56., 49.6, 28., 14.6, 48.])

    unique_arr, counts = np.unique(arr, return_counts=True)

    # 找到重复的元素
    duplicate_arr = unique_arr[counts > 1]

    print("重复的元素：", duplicate_arr)