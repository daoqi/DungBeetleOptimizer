"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:compare_diff_opt.py
@Created Time: 2023.04.21
"""

import sys
import concurrent
import os.path

# 将DungBeetleOptimizer 放入搜索路径
import threading

sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(os.path.abspath(__file__)))))
import time
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from tqdm import tqdm, trange
from discrete_ga import GeneticAlgorithm
from discrete_adbo import DiscreteADBO
from dssa import DSSA
from pso import PSO
from test_function import *
from configuration import config
from criteria_util import Criteria
from globals import util
from data_parser import parser_data

_DATA_SET_PATH = r"../task_allocation_dataset"
EXP_TIME = 1

_POPULATION_SIZE = 30
_MAX_ITERATION = 200
_STEP = _MAX_ITERATION // 4  # 导出数据的步长
_ROLE_AMOUNT_DISTRIBUTION = [0.2, 0.2, 0.2, 0.4]
# 优化后的DBO
_DBO_ADVANCED_PARAMETER_DICT = {
    "mu": 1.02,
    "levy_rate": 0.2,
    "beta": 1.5,
    "predation_coe": 0.1
}
# 优化方法测试顺序
OPT_TEST_SEQ = ["DDBO", "GA", "PSO", "DSSA"]
# 测试案例文件名(不带后缀)
_CASE_NAME_LIST = []

# _CASE_NAME_LIST = ["case_2_1","case_2_2","case_2_3","case_2_4","case_2_5","case_2_6","case_2_7","case_2_8","case_2_9","case_2_10"]
# _CASE_NAME_LIST = ["case_3_1", "case_3_2", "case_3_3", "case_3_4", "case_3_5", "case_3_6", "case_3_7", "case_3_8", "case_3_9", "case_3_10"]

for filename in os.listdir(_DATA_SET_PATH):
    filename_without_suffix = filename.split(".")[0]
    if filename_without_suffix != "ReadMe" and not filename.endswith(".zip"):
        _CASE_NAME_LIST.append(filename_without_suffix)
print("实验案例列表: ", _CASE_NAME_LIST)


def gen_ddbo_opt(worker_dict, task_dict, low_boundary, up_boundary) -> DiscreteADBO:
    ddbo = DiscreteADBO(worker_dict=worker_dict,
                        simulation_task_dict=task_dict,
                        population_size=_POPULATION_SIZE,
                        max_iteration=_MAX_ITERATION,
                        lb=low_boundary,
                        ub=up_boundary,
                        role_amount_distribution=_ROLE_AMOUNT_DISTRIBUTION,
                        param_dict=_DBO_ADVANCED_PARAMETER_DICT)
    return ddbo


def gen_ga_opt(worker_dict, task_dict, low_boundary, up_boundary) -> GeneticAlgorithm:
    ga = GeneticAlgorithm(worker_dict=worker_dict,
                          simulation_task_dict=task_dict,
                          population_size=_POPULATION_SIZE,
                          max_iteration=_MAX_ITERATION,
                          lb=low_boundary,
                          ub=up_boundary,
                          crossover_rate=0.8,
                          mutation_rate=0.1,
                          encoding_length=10,
                          )

    return ga


def gen_pso_opt(worker_dict, task_dict, low_boundary, up_boundary):
    pso = PSO(worker_dict=worker_dict,
              simulation_task_dict=task_dict,
              population_size=_POPULATION_SIZE,
              max_iteration=_MAX_ITERATION,
              lb=low_boundary,
              ub=up_boundary,
              w=0.8,
              c1=2,
              c2=2,
              r1=0.6,
              r2=0.3
              )
    return pso


def gen_dssa_opt(worker_dict, task_dict, low_boundary, up_boundary):
    dssa = DSSA(worker_dict=worker_dict,
                simulation_task_dict=task_dict,
                population_size=_POPULATION_SIZE,
                max_iteration=_MAX_ITERATION,
                lb=low_boundary,
                ub=up_boundary,
                ST=0.6,
                PD=0.7,
                SD=0.2)

    return dssa


def run_optimize_function(obj):
    return obj.optimize()


def export_to_file(file_dir: str, file_name: str, content: str):
    if not os.path.exists(file_dir):
        os.makedirs(file_dir)
    file_path = os.path.join(file_dir, file_name)
    with open(file=file_path, mode="w", encoding="utf-8") as f:
        f.write(content)


def handle_experiment_result(res_dict, avg_ddbo_curve, avg_ga_curve, avg_pso_curve, avg_dssa_curve, content_dict):
    final_dict = {
        "DDBO": [],
        "GA": [],
        "PSO": [],
        "DSSA": []
    }

    avg_ddbo_curve = avg_ddbo_curve.flatten().tolist()
    avg_ga_curve = avg_ga_curve.flatten().tolist()
    avg_pso_curve = avg_pso_curve.flatten().tolist()
    avg_dssa_curve = avg_dssa_curve.flatten().tolist()

    for opt_k in OPT_TEST_SEQ:
        all_best_score = res_dict[opt_k]["best score"]
        all_best_position = res_dict[opt_k]["best position"]
        all_best_position = np.array(all_best_position).reshape(len(all_best_position), all_best_position[0].shape[1])

        criteria = Criteria(result_list=all_best_score)
        c_mean = criteria.calculate_mean()
        c_standard_deviation = criteria.calculate_standard_deviation()
        final_dict[opt_k].append(c_mean)
        final_dict[opt_k].append(c_standard_deviation)
        final_dict[opt_k].append(np.average(all_best_position, axis=0))

    content = "Experiment numbers: {}\n" \
              "Case name: {}\n" \
              "DDBO average minima: {} ,std: {}, average best position: {}, average optimize curve: {}\n" \
              "GA average minima: {} ,std: {}, average best position: {}, average optimize curve: {}\n" \
              "DSSA average minima: {} ,std: {}, average best position: {}, average optimize curve: {}\n" \
              "PSO average minima: {} ,std: {}, average best position: {}, average optimize curve: {}\n".format(
        content_dict["exp number"],
        content_dict["case name"],
        final_dict["DDBO"][0], final_dict["DDBO"][1], final_dict["DDBO"][2], avg_ddbo_curve,
        final_dict["GA"][0], final_dict["GA"][1], final_dict["GA"][2], avg_ga_curve,
        final_dict["DSSA"][0], final_dict["DSSA"][1], final_dict["DSSA"][2], avg_dssa_curve,
        final_dict["PSO"][0], final_dict["PSO"][1], final_dict["PSO"][2], avg_pso_curve,

    )
    file_name = "{}_{}".format(content_dict["case name"], content_dict["exp number"])
    file_dir = os.path.join(config.RESULT_SAVING_PATH, content_dict["case name"])

    export_to_file(file_dir=file_dir, file_name=file_name + ".txt", content=content)
    util.export_figure(figure_title="Optimization curve (Case: {})".format(content_dict["case name"]),
                       line_name_list=OPT_TEST_SEQ,
                       y_list=[avg_ddbo_curve, avg_ga_curve, avg_pso_curve, avg_dssa_curve],
                       is_save=True,
                       is_log=True,
                       file_dir=file_dir,
                       file_name=file_name + "_optimize curve")


def start_exp():
    thread_pool = ThreadPoolExecutor(max_workers=os.cpu_count() * 2)

    for case_name in _CASE_NAME_LIST:
        worker_dict, task_dict = parser_data(case_path=os.path.join(_DATA_SET_PATH, case_name + ".txt"))
        # print("case name:{}, worker number: {}, task number: {}".format(case_name,len(worker_dict),len(task_dict)))
        dim = len(worker_dict) + len(task_dict)

        # 需要导出的实验数据
        res_dict = {
            "DDBO": {
                "best score": [],
                "best position": [],
            },
            "GA": {
                "best score": [],
                "best position": [],
            },
            "PSO": {
                "best score": [],
                "best position": [],
            },
            "DSSA": {
                "best score": [],
                "best position": [],
            },
        }

        # 记录n实验的平均年搜索结果,curve->每次迭代的最优解对应函数值
        avg_ddbo_curve = []
        avg_ga_curve = []
        avg_pso_curve = []
        avg_dssa_curve = []

        print("\033[31m实验次数:{},优化案例:{},优化目标个数:{}\033[0m".format(
            EXP_TIME,
            case_name,
            dim,
        ))

        for exp_cnt in range(1, EXP_TIME + 1):
            print("\033[32m***** Start experiment {} *****\033[0m".format(exp_cnt))
            s_time = time.time()
            low_boundary = 1 * np.ones((dim, 1))
            up_boundary = (dim - 1) * np.ones((dim, 1))
            ddbo_opt = gen_ddbo_opt(worker_dict=worker_dict, task_dict=task_dict,
                                    low_boundary=low_boundary, up_boundary=up_boundary)
            ga_opt = gen_ga_opt(worker_dict=worker_dict, task_dict=task_dict,
                                low_boundary=low_boundary, up_boundary=up_boundary)

            pso_opt = gen_pso_opt(worker_dict=worker_dict, task_dict=task_dict,
                                  low_boundary=low_boundary, up_boundary=up_boundary)

            dssa_opt = gen_dssa_opt(worker_dict=worker_dict, task_dict=task_dict,
                                    low_boundary=low_boundary, up_boundary=up_boundary)

            temp_res = []
            for result in thread_pool.map(run_optimize_function, [ddbo_opt, ga_opt, pso_opt, dssa_opt]):
                """
                    result[0][0] is double 
                    result[1] is np.ndarray(1,30)
                """
                temp_res.append(result)
            index = 0
            for k in OPT_TEST_SEQ:
                res_dict[k]["best score"].append(temp_res[index][0][0])
                res_dict[k]["best position"].append(temp_res[index][1])
                index += 1
            e_time = time.time()
            print("\033[32mExperiment %d is over,consuming time: %.3f s\033[0m" % (exp_cnt, (e_time - s_time)))
            ddbo_positions, ddbo_curves = ddbo_opt.export_optimization_procedure(step=_STEP)
            ga_positions, ga_curves = ga_opt.export_optimization_procedure(step=_STEP)
            pso_positions, pso_curves = pso_opt.export_optimization_procedure(step=_STEP)
            dssa_positions, dssa_curves = dssa_opt.export_optimization_procedure(step=_STEP)
            avg_ddbo_curve.append(ddbo_curves)
            avg_ga_curve.append(ga_curves)
            avg_pso_curve.append(pso_curves)
            avg_dssa_curve.append(dssa_curves)

        avg_ddbo_curve = np.average(np.array(avg_ddbo_curve), axis=0)
        avg_ga_curve = np.average(np.array(avg_ga_curve), axis=0)
        avg_pso_curve = np.average(np.array(avg_pso_curve), axis=0)
        avg_dssa_curve = np.average(np.array(avg_dssa_curve), axis=0)
        content_dict = {
            "exp number": EXP_TIME,
            "case name": case_name,
        }
        print("Content dict: ", content_dict)
        handle_experiment_result(res_dict=res_dict,
                                 avg_ddbo_curve=avg_ddbo_curve,
                                 avg_ga_curve=avg_ga_curve,
                                 avg_pso_curve=avg_pso_curve,
                                 avg_dssa_curve=avg_dssa_curve,
                                 content_dict=content_dict)

        # export_to_file("experiment result {}_{}.txt".format(_function_name, EXP_TIME,content="" )


if __name__ == '__main__':
    start_exp()
