"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:dung_beetle_opt.py
@Created Time: 2023.04.15
"""
import copy
import math
import os
import time
import matplotlib.pyplot as plt
import numpy as np
from numba import jit
from globals import DungBeetleRoleEnum, util
from globals import check_amount_distribution
from configuration import set_global_randomness, config
from globals.chaotic_mapping import SingerMapping, LogisticMapping
from data_parser import parser_data

plt.rc('font', family='Times New Roman')
set_global_randomness()

# 代表一个空任务
NOT_A_NUMBER = np.nan
ALGORITHM_NAME = "DDBO without balancer"


class DiscreteADBO:

    def __init__(self,
                 worker_dict,
                 simulation_task_dict,
                 population_size: int,
                 max_iteration: int,
                 lb: np.ndarray,
                 ub: np.ndarray,
                 role_amount_distribution: list,
                 param_dict: dict = None):

        self.__worker_dict = worker_dict
        self.__simulation_task_dict = simulation_task_dict
        self.__n_dim = len(simulation_task_dict) + len(worker_dict)
        self.__population_size = population_size
        self.__max_iteration = max_iteration
        self.__lb = lb
        self.__ub = ub
        self.__role_ub = [0, 0, 0, 0]
        self.__best_score_curve = np.zeros((self.__max_iteration, 1))
        self.__best_score_position = np.zeros((self.__max_iteration, self.__n_dim))
        self.__param_dict = param_dict
        if "predation_coe" not in param_dict:
            self.__predation_coe = 0.2
        else:
            self.__predation_coe = param_dict["predation_coe"]
        if check_amount_distribution(role_amount_distribution):
            self.__amount_distribution = role_amount_distribution
            self.__gen_role_range()
            # print("四种角色的蜣螂下标范围: ", self.__role_ub)
        else:
            raise ValueError("蜣螂种群的角色分布不满足定义,错误分布:{}".format(role_amount_distribution))

    def export_optimization_procedure(self):
        """
            导出优化过程中的最优解和其函数值
        :return:
        """
        return self.__best_score_position, self.__best_score_curve

    def draw_optimization_curve(self, is_save=True, file_str=""):
        x = [i for i in range(0, self.__best_score_curve.shape[0])]
        y = self.__best_score_curve[:, 0]
        plt.title("Optimization Curve(advanced-with predator)")
        # if self.__best_score_curve.all() > 0.0:
        #     plt.yscale("log")
        plt.plot(x, y)
        plt.xlabel("Epoch")
        plt.ylabel("Current epoch best score")
        if not is_save:
            plt.show()
        else:
            if len(file_str) == 0:
                file_str = time.strftime("%Y-%m-%d %H-%M-%S", time.localtime(time.time()))
            plt.savefig(os.path.join(config.IMAGE_SAVING_PATH, "AdvancedDungBeetleOpt-with predator" + file_str))

    def __gen_role_range(self):
        """
            根据数量分布分别依次生成滚球蜣螂，产卵蜣螂,觅食蜣螂,偷窃蜣螂这四种角色的下标范围
        """
        last_num = 0
        for index in range(0, len(self.__amount_distribution)):
            last_num = last_num + round(self.__population_size * self.__amount_distribution[index])
            self.__role_ub[index] = last_num

    def __check_border(self, x):
        """
            x的值超出了搜索范围
        :param x:
        :return:
        """
        for i in range(self.__population_size):
            for j in range(self.__n_dim):
                if x[i, j] > self.__ub[j]:
                    x[i, j] = self.__ub[j]
                elif x[i, j] < self.__lb[j]:
                    x[i, j] = self.__lb[j]
        return x

    def __restrict_solution(self, x: np.ndarray) -> np.ndarray:
        x_new = x
        # 约束解小于等于-1的值为-1
        for i in range(self.__population_size):
            for j in range(self.__n_dim):
                if x_new[i, j] < 0:
                    x_new[i, j] = NOT_A_NUMBER
        return x

    def __initialize_population(self):
        row_num = self.__population_size
        worker_num = len(self.__worker_dict)
        task_num = len(self.__simulation_task_dict)
        col_num = task_num + worker_num
        res_solution = np.zeros(shape=(row_num, col_num))
        for i in range(0, row_num):
            task_id_list = list(self.__simulation_task_dict.keys())
            for j in range(0, task_num):
                pop_task_id = np.random.choice(task_id_list, replace=False)
                res_solution[i, j] = pop_task_id
                task_id_list.remove(pop_task_id)
            surplus_task = copy.deepcopy(task_num)
            for j in range(task_num, col_num):
                if j == col_num - 1:
                    # 以保证 sum(res[i,task_num:col_num-1]) == task_num
                    res_solution[i, col_num - 1] = surplus_task
                    break
                allocation_num = np.random.randint(0, surplus_task)
                res_solution[i, j] = allocation_num
                surplus_task -= allocation_num

        return res_solution

    def __roll_ball_update(self, x, x_last_epoch, global_worst_position):
        """
            滚球与跳舞行为
        """

        x_new = copy.deepcopy(x)
        eta = np.random.rand(1)
        col_num = len(self.__simulation_task_dict)
        b = 0.3
        for i in range(0, self.__role_ub[DungBeetleRoleEnum.ROLL_BALL_DUNG_BEETLE.value]):
            if eta < 0.9:
                alpha = np.random.rand(1)
                if alpha > 0.1:
                    alpha = 1
                else:
                    alpha = -1

                x_new[i, :col_num] = x[i, :col_num] + b * np.abs(
                    x[i, :col_num] - global_worst_position[0, :col_num]) + alpha * 0.1 * (
                                         x_last_epoch[i, :col_num])  # Equation(1)
            else:
                # dance
                theta = np.random.randint(180, size=1)
                if theta == 0 or theta == 90 or theta == 180:
                    for j in range(0, col_num):
                        x_new[i, j] = x[i, j]
                temp_theta = theta * np.pi / 180
                x_new[i, :col_num] = x[i, :col_num] + math.tan(temp_theta) * np.abs(
                    x[i, :col_num] - x_last_epoch[i, :col_num])  # Equation(2)
        return x_new

    def __brood_ball_update(self, x, epoch, fitness_array):
        """
            产卵(繁殖)行为
        """
        col_num = len(self.__simulation_task_dict)
        x_new = copy.copy(x)
        r = 1 - epoch / self.__max_iteration
        # 找到x最小适应度的索引
        best_index = np.argmin(fitness_array)
        # 找到最优的蜣螂位置
        best_x = x[best_index, :col_num]
        lb_star = best_x * (1 - r)
        ub_star = best_x * (1 + r)
        # lb_star[lb_star.is_nan()] = -np.inf
        # ub_star[ub_star.is_nan()] = -np.inf
        for row_i in range(0, col_num):
            # Equation(3)
            lb_star[row_i] = max(lb_star[row_i], self.__lb[row_i])
            ub_star[row_i] = max(ub_star[row_i], self.__ub[row_i])
        for i in range(self.__role_ub[DungBeetleRoleEnum.ROLL_BALL_DUNG_BEETLE.value] + 1,
                       self.__role_ub[DungBeetleRoleEnum.BROOD_BALL_DUNG_BEETLE.value]):
            # Equation(4)
            x_new[i, :col_num] = best_x + (np.random.rand(1, col_num)) * (
                    x[i, :col_num] - lb_star + (np.random.rand(1, col_num)) * (x[i, :col_num] - ub_star))
            for j in range(col_num):
                x_new[i, j] = np.clip(x_new[i, j], lb_star[j], ub_star[j])
        return x_new

    def __forage_update(self, x, epoch, fitness_array, global_best_position):
        """
            小屎壳郎觅食更新
        """
        x_new = copy.copy(x)
        col_num = len(self.__simulation_task_dict)
        r = 1 - epoch / self.__max_iteration
        lbb = global_best_position[0, :col_num] * (1 - r)
        ubb = global_best_position[0, :col_num] * (1 + r)
        for j in range(col_num):
            lbb[j] = np.clip(lbb[j], self.__lb[j], self.__ub[j])  # Equation(5)
            ubb[j] = np.clip(ubb[j], self.__lb[j], self.__ub[j])  # Equation(5)
        for i in range(self.__role_ub[DungBeetleRoleEnum.BROOD_BALL_DUNG_BEETLE.value] + 1,
                       self.__role_ub[DungBeetleRoleEnum.FORAGE_BALL_DUNG_BEETLE.value]):  # Equation(6)
            x_new[i, :col_num] = x[i, :col_num] + (np.random.rand(1, col_num)) * \
                                 (x[i, :col_num] - lbb) + (np.random.rand(1, col_num)) * \
                                 (x[i, :col_num] - ubb)
            for j in range(col_num):
                x_new[i, j] = np.clip(x_new[i, j], lbb[j], ubb[j])
        return x_new

    def __thieve_update(self, x, epoch, global_best_position, fitness_array):
        """
            偷窃更新
        """
        x_new = copy.copy(x)
        col_num = len(self.__simulation_task_dict)
        f_min = np.min(fitness_array)  # 找到x中最小的适应度
        bestIndex = np.argmin(fitness_array)  # 找到x中最小适应度的索引
        best_x = x[bestIndex, :col_num]  # 找到x中具有最有适应度的蜣螂位置
        for i in range(self.__role_ub[DungBeetleRoleEnum.FORAGE_BALL_DUNG_BEETLE.value] + 1,
                       self.__population_size):  # Equation(7)
            x_new[i, :col_num] = global_best_position[0, :col_num] + np.random.randn(1, col_num) * (
                    np.abs(x[i, :col_num] - global_best_position[0, :col_num]) + np.abs(x[i, :col_num] - best_x)) / 2
            for j in range(col_num):
                x_new[i, j] = np.clip(x_new[i, j], self.__lb[j], self.__ub[j])
        return x_new

    def __levy_flight(self, last_x, beta=1.5):
        """
            为单一个体添加levy飞行策略
        :param last_x:(1,len(self.__simulation_task_dict))
        :param beta:
        :return:
        """
        col_num = len(self.__simulation_task_dict)
        res_x = np.zeros(shape=(1, col_num))
        alpha_u = math.pow((np.math.gamma(1 + beta) * math.sin(math.pi * beta / 2) /
                            (np.math.gamma(((1 + beta) / 2) * beta * math.pow(2, (beta - 1) / 2)))),
                           (1 / beta))
        alpha_v = 1
        for j in range(0, col_num):
            u = np.random.normal(0, alpha_u, 1)
            v = np.random.normal(0, alpha_v, 1)
            step = u / math.pow(abs(v), (1 / beta))
            res_x[0, j] = last_x[0, j] + step
        return res_x

    def __gen_x_without_nan(self, x: np.ndarray):
        task_number = len(self.__simulation_task_dict)
        res = np.zeros(shape=(self.__population_size, task_number))
        for row_index in range(0, self.__population_size):
            j = 0
            for task_group_id in range(0, self.__n_dim, task_number):
                for col in range(task_group_id, task_group_id + task_number):
                    if not np.isnan(x[row_index, col]):
                        # print("row_index: {}, j: {},val:{}".format(row_index,j,x[row_index, col]))
                        res[row_index, j] = x[row_index, col]
                        j += 1

        return res

    def __decode_to_discrete(self, discrete_x_old: np.ndarray, continuous_x_old):
        """
            应用DSSA中的离散方式将经过函数运算后的连续值映射回离散值
        :param discrete_x_old:
        :param continuous_x_old:
        :return:
        """
        assert discrete_x_old.shape == continuous_x_old.shape

        task_num = len(self.__simulation_task_dict)
        row_n = continuous_x_old.shape[0]
        res_x = np.zeros((row_n, self.__n_dim), dtype="int")
        # if self.__check_discrete_x(discrete_x_old, "discrete old") is False:
        #     exit()
        sorted_discrete_x_old = np.sort(discrete_x_old[:, :task_num], axis=1)
        sorted_continuous_x = np.sort(continuous_x_old[:, :task_num], axis=1)
        for row_index in range(0, self.__population_size):
            vis = np.full(shape=(1, task_num), fill_value=False)
            for col_index in range(0, task_num):
                to_search_target = continuous_x_old[row_index, col_index]
                for search_j in range(0, task_num):
                    elem_in_sorted_continuous_x = sorted_continuous_x[row_index, search_j]
                    if math.isclose(to_search_target, elem_in_sorted_continuous_x) and (not vis[0, search_j]):
                        res_x[row_index, col_index] = sorted_discrete_x_old[row_index, search_j]
                        vis[0, search_j] = True
                        break
                    else:
                        continue
            for assignment_j in range(task_num, self.__n_dim):
                res_x[row_index, assignment_j] = discrete_x_old[row_index, assignment_j]
        # if self.__check_discrete_x(res_x, "discrete") is False:
        #     exit()
        return res_x

    def __gen_allocation_list_from_solution(self, x: np.ndarray):
        """
        :param x:
        :return: list [[],...,[]]
        """

        res_allocation_list = []
        task_number = len(self.__simulation_task_dict)
        worker_number = len(self.__worker_dict)
        for i in range(0, x.shape[0]):
            s = 0
            allocation_list = []
            for j in range(1, worker_number + 1):
                worker_allocation_number = int(x[i, task_number + (j - 1)])
                worker_load = x[i, s:s + worker_allocation_number]
                s += worker_allocation_number
                allocation_list.append(worker_load)
            res_allocation_list.append(allocation_list)
        return res_allocation_list

    def __sum_complexity(self, x, c0=0.5, c1=0.5):
        """

        :param x: []
        :param c0:
        :param c1:
        :return:
        """
        total_sum = 0

        if x.shape[0] <= 0:
            return 0
        for task_index, task_id in enumerate(x):
            task_id = int(task_id)

            vertex_num = self.__simulation_task_dict[task_id][0]
            edge_num = self.__simulation_task_dict[task_id][1]
            priority = self.__simulation_task_dict[task_id][2]
            total_sum += (c0 * vertex_num + c1 * edge_num) + (priority * task_index)
        return total_sum

    def __evaluate_total_cost(self, x):
        """
            评估一组分配方式的最大代价
        :param x: allocation result [[],...,[]]
        :return:
        """
        res_list = []
        worker_num = len(self.__worker_dict)

        for worker_index in range(0, worker_num):
            worker_id = worker_index + 1
            worker_capacity = self.__worker_dict[worker_id]
            group_complexity = self.__sum_complexity(x[worker_index], c0=0.5, c1=0.5)
            dispersion_cost = np.std([len(elem) for elem in x])
            # print("group_complexity:{},worker_capacity:{},dispersion_cost:{}".format(group_complexity,worker_capacity,dispersion_cost))
            cost = group_complexity / worker_capacity + dispersion_cost
            res_list.append(cost)

        # print("Allocation cost: ",res_list)
        return max(res_list)

    def __calculate_fitness(self, x: np.ndarray) -> np.ndarray:
        """
            计算任务分配的适应度函数,在一组解中任务id应该是唯一的
        :param x:
        :return:
        """
        row_num = x.shape[0]
        fitness = np.zeros([row_num, 1])
        allocation_result = self.__gen_allocation_list_from_solution(x)

        for i in range(0, row_num):
            try:
                fitness[i] = self.__evaluate_total_cost(allocation_result[i])
                # print("计算:{},适应度:{}".format(x[i, :],fitness[i]))
            except KeyError as e:
                print("[__calculate_fitness] Error index:{}".format(i))
                print("[__calculate_fitness] Error allocation result:{}".format(allocation_result[i]))
                print(x[i, :])
                print(e)
                exit()
        return fitness

    def __sort_fitness(self, fitness_array) -> tuple:
        sorted_fitness = np.sort(fitness_array, axis=0)
        index = np.argsort(fitness_array, axis=0)
        return sorted_fitness, index

    def __regenerate_sorted_x_array(self, x_old: np.ndarray, index_old: np.ndarray) -> np.ndarray:
        """
            适应度函数越小的解，在新的解集中的位置越靠近第0行
        """
        row_num = x_old.shape[0]
        x_new = np.zeros(x_old.shape)
        for i in range(0, row_num):
            x_new[i, :] = x_old[index_old[i], :]
        return x_new

    def __calculate_dispersion_degree(self, x):
        """
            计算种群离散程度,方差
        :param x:
        :return:
        """
        task_num = len(self.__simulation_task_dict)
        variances = np.var(x[:, task_num:], axis=0)
        total_variance = np.sum(variances)
        return total_variance

    def __modify_predator_coefficient(self, last_dispersion_degree, new_dispersion_degree):
        """
            更新捕食者系数,捕食者系数越大,屎壳郎的被捕食率越高,捕食者系数取决于:
                1. 屎壳郎的种群离散程度
                2. 捕食者的注意程度
            屎壳郎种群离散,且捕食者警惕度低时,降低捕食系数
            屎壳郎种群密集,且捕食者警惕度高时,提高捕食系数
        :param last_dispersion_degree:
        :param new_dispersion_degree:
        :return:
        """
        predator_attention = np.random.randn(1)
        predator_awareness = 0.3
        float_degree = np.random.uniform(0.001, 0.05)
        if self.__predation_coe < 0.0 or self.__predation_coe > 0.3:
            self.__predation_coe = 0.15
        if new_dispersion_degree > last_dispersion_degree:
            # 种群整体更离散,降低捕食率或者保持不动
            if predator_attention < predator_awareness:
                self.__predation_coe -= float_degree
        else:
            # 种群整体更密集,同时受到了捕食者的关注
            if predator_attention > (1 - predator_awareness):
                self.__predation_coe += float_degree

    def __calculate_p_of_counter_attack(self, i, a=1.0):
        res = math.exp(-a * i / self.__n_dim)
        return res

    def __predate_successful(self, discrete_x_old, continuous_x_old, dead_index):
        """

        :param discrete_x_old:
        :param dead_index: 需要被捕食个体的下标
        :return:
        """
        col_num = len(self.__simulation_task_dict)
        for i in range(0, self.__population_size):
            p_of_counter_attack = self.__calculate_p_of_counter_attack(i, a=1.0)
            alpha = np.random.randn(1)
            if alpha > 0.2:
                # 咬击更新
                pass
            else:
                # 逃跑
                rate = self.__param_dict["levy_rate"]
                beta = self.__param_dict["beta"]
                continuous_x_old[i, 0:col_num] = self.__levy_flight(
                    last_x=continuous_x_old[i, 0:col_num].reshape(1, col_num),
                    beta=beta)

        discrete_x = self.__decode_to_discrete(discrete_x_old=discrete_x_old, continuous_x_old=continuous_x_old)
        fitness_array = self.__calculate_fitness(discrete_x)
        sorted_fitness, index = self.__sort_fitness(fitness_array=fitness_array)
        discrete_x = self.__regenerate_sorted_x_array(x_old=discrete_x_old, index_old=index)
        for i in range(dead_index, self.__population_size):
            # 屎壳郎被捕食(将这些个体重新进行初始化)-差分演化
            # 1. 从x_new[dead_index,self.__population_size] 中随机抽取三行解
            factor = np.random.uniform()
            row_sequence = np.random.choice(self.__population_size, 3, replace=False, p=None)
            diff_matrix = continuous_x_old[row_sequence, :col_num]
            continuous_x_old[i, :col_num] = diff_matrix[0, :col_num] + factor * (
                    diff_matrix[1, :col_num] - diff_matrix[2, :col_num])

        discrete_x = self.__decode_to_discrete(discrete_x_old=discrete_x, continuous_x_old=continuous_x_old)
        fitness_array = self.__calculate_fitness(discrete_x)
        fitness_array, index = self.__sort_fitness(fitness_array=fitness_array)
        discrete_x = self.__regenerate_sorted_x_array(x_old=discrete_x, index_old=index)

        return discrete_x

    def __predate_failure(self, discrete_x_old, continuous_x_old, dead_index):
        col_num = len(self.__simulation_task_dict)
        for i in range(dead_index, self.__population_size):
            continuous_x_old[i, :col_num] = np.random.randn() * np.exp(
                (continuous_x_old[-1, :col_num] - continuous_x_old[i, :col_num]) / i ** 2)
        discrete_x = self.__decode_to_discrete(discrete_x_old=discrete_x_old, continuous_x_old=continuous_x_old)
        return discrete_x

    def __allocation_method_update(self, x: np.ndarray):
        """
            更新服务器分配方式
        :param x: (pop size,num of tasks + num of servers)
        :return:
        """

        task_num = len(self.__simulation_task_dict)
        worker_num = len(self.__worker_dict)
        k = math.ceil(worker_num * self.__predation_coe)
        for i in range(0, self.__population_size):
            alpha = np.random.rand()
            if alpha > 0.5:
                k_max_index_list = np.argsort(x[i, task_num:])[-k:]
                k_min_index_list = np.argsort(x[i, task_num:])[0:k]
                for index in range(0, k):
                    if x[i, task_num + k_max_index_list[index]] > 1:
                        x[i, task_num + k_max_index_list[index]] -= 1
                        x[i, task_num + k_min_index_list[index]] += 1

        return x

    def __predation_update(self, discrete_x_old, continuous_x_old):
        """
            捕食更新
        :param x_old:
        :return:
        """
        x_new = copy.deepcopy(discrete_x_old)
        eta = np.random.randn()
        dead_index = self.__population_size - int(self.__population_size * self.__predation_coe)

        if eta < 0.3:
            # 捕食成功
            x_new = self.__predate_successful(discrete_x_old=x_new,
                                              continuous_x_old=continuous_x_old,
                                              dead_index=dead_index)

        else:
            # 捕食失败,屎壳郎心有余悸,抱团更新
            x_new = self.__predate_failure(discrete_x_old=discrete_x_old,
                                           continuous_x_old=continuous_x_old,
                                           dead_index=dead_index)

        return x_new

    def __check_solution_validation(self, x: np.ndarray):
        """
            用于判断解集是否合法
                1. 任务列表中的task id 不可缺失，重复
                2. 分配方式中服务器的任务分配之和必须是任务总数量
        :param x:
        :return:
        """
        reinitialize_individual_set = set()
        task_num = len(self.__simulation_task_dict)
        for i in range(0, self.__population_size):
            task_check_dict = {}
            for j in range(0, task_num):
                k = int(x[i, j])
                if k > task_num or k < 1:
                    reinitialize_individual_set.add(i)
                if k not in task_check_dict.keys():
                    task_check_dict[k] = 1
                else:
                    task_check_dict[k] += 1
            for key in list(task_check_dict.keys()):
                val = task_check_dict[key]
                if val != 1:
                    reinitialize_individual_set.add(i)
            if int(sum(x[i, task_num:])) != task_num:
                reinitialize_individual_set.add(i)
        # 重新初始化
        col_num = len(self.__simulation_task_dict) + len(self.__worker_dict)
        for i in reinitialize_individual_set:
            task_id_list = list(self.__simulation_task_dict.keys())
            for j in range(0, task_num):
                pop_task_id = np.random.choice(task_id_list, replace=False)
                x[i, j] = pop_task_id
                task_id_list.remove(pop_task_id)
            surplus_task = copy.deepcopy(task_num)
            for j in range(task_num, col_num):
                if j == col_num - 1:
                    # 以保证 sum(res[i,task_num:col_num-1]) == task_num
                    x[i, col_num - 1] = surplus_task
                    break
                allocation_num = np.random.randint(0, surplus_task)
                x[i, j] = allocation_num
                surplus_task -= allocation_num
        return x

    def __check_discrete_x(self, x: np.ndarray, row):
        reinitialize_individual_set = set()
        task_num = len(self.__simulation_task_dict)
        for i in range(0, x.shape[0]):
            task_check_dict = {}
            for j in range(0, task_num):
                k = int(x[i, j])
                if k > task_num or k == 0:
                    reinitialize_individual_set.add(i)
                    print("!!![Check row:({},{})]!!! task id(k):{}".format(row, i, k))
                if k not in task_check_dict.keys():
                    task_check_dict[k] = 1
                else:
                    task_check_dict[k] += 1
            for key in list(task_check_dict.keys()):
                val = task_check_dict[key]
                if val != 1:
                    print("!!![Check row:{},index:{}]!!! task id (key):{}, numbers:{}".format(row, i, key, val))
                    reinitialize_individual_set.add(i)

            if int(sum(x[i, task_num:])) != task_num:
                reinitialize_individual_set.add(i)
                print("!!![Check row:{},index:{}]!!! 任务和错误 {}!={}".format(row, i, sum(x[i, task_num:]), task_num))
        if len(reinitialize_individual_set) > 0:
            print("!!![Check row:{}]!!! x is not valid, len:{}".format(row,
                                                                       len(reinitialize_individual_set)),
                  reinitialize_individual_set)
            for problem_id in reinitialize_individual_set:
                print("problem id:{}".format(problem_id), x[problem_id, :])
            return False

        return True

    def __print_solution(self, x: np.ndarray, decode=False):
        task_num = len(self.__simulation_task_dict)
        worker_num = len(self.__worker_dict)
        if decode is False:
            for i in range(0, x.shape[0]):
                for j in range(0, task_num):
                    if j == task_num - 1:
                        print(int(x[i, j]), end="")
                    else:
                        print(int(x[i, j]), end=" , ")

                for j in range(task_num, task_num + worker_num):
                    if j == task_num:
                        print(" | {},".format(x[i, j]), end="")
                    else:
                        print("{},".format(x[i, j]), end="")
                print()
        else:
            x = x.reshape((1, self.__n_dim))
            res = self.__gen_allocation_list_from_solution(x)
            res_str = ""
            for row in range(0, x.shape[0]):
                for index, allocation_list in enumerate(res[row]):
                    res_str += " Allocation {}: {}".format(index + 1, allocation_list)
            return res_str

    def __describe_best_position(self, best_position: np.ndarray):
        print("Workers information: ")
        for key in list(self.__worker_dict.keys()):
            print("Worker id:{}, Worker Capability:{}".format(key, self.__worker_dict[key]))
        print("task allocation: ")
        print(self.__print_solution(x=best_position, decode=True))
        print("Cost: ", self.__calculate_fitness(x=best_position))

    def optimize(self):
        print("[{}] Optimizer starts to work! ".format(ALGORITHM_NAME))
        discrete_x = self.__initialize_population()
        fitness_array = self.__calculate_fitness(discrete_x)
        fitness_array, index = self.__sort_fitness(fitness_array=fitness_array)
        discrete_x = self.__regenerate_sorted_x_array(x_old=discrete_x, index_old=index)

        last_dispersion_degree = self.__calculate_dispersion_degree(x=discrete_x)
        x_last_epoch = discrete_x  # x(t-1)
        global_best_score = fitness_array[0]
        global_best_position = np.zeros((1, self.__n_dim))
        global_best_position[0, :] = discrete_x[0, :]

        global_worst_score = fitness_array[-1]
        global_worst_position = np.zeros((1, self.__n_dim))
        global_worst_position[0, :] = discrete_x[-1, :]

        for epoch in range(self.__max_iteration):
            # 滚球和舞蹈行为
            x = self.__roll_ball_update(x=discrete_x, x_last_epoch=x_last_epoch,
                                        global_worst_position=global_worst_position)

            discrete_x = self.__decode_to_discrete(discrete_x_old=discrete_x, continuous_x_old=x)
            fitness_array = self.__calculate_fitness(discrete_x)
            # 繁殖行为
            x = self.__brood_ball_update(x, epoch=epoch, fitness_array=fitness_array)
            discrete_x = self.__decode_to_discrete(discrete_x_old=discrete_x, continuous_x_old=x)
            fitness_array = self.__calculate_fitness(discrete_x)

            # 觅食行为
            x = self.__forage_update(x, epoch=epoch, fitness_array=fitness_array,
                                     global_best_position=global_best_position)

            discrete_x = self.__decode_to_discrete(discrete_x_old=discrete_x, continuous_x_old=x)
            fitness_array = self.__calculate_fitness(discrete_x)
            # 偷窃行为
            x = self.__thieve_update(x, epoch=epoch, global_best_position=global_best_position,
                                     fitness_array=fitness_array)
            discrete_x = self.__decode_to_discrete(discrete_x_old=discrete_x, continuous_x_old=x)
            fitness_array = self.__calculate_fitness(discrete_x)
            fitness_array, index = self.__sort_fitness(fitness_array=fitness_array)
            discrete_x = self.__regenerate_sorted_x_array(x_old=discrete_x, index_old=index)


            # 捕食屎壳郎
            dispersion_degree = self.__calculate_dispersion_degree(discrete_x)
            self.__modify_predator_coefficient(last_dispersion_degree=last_dispersion_degree,
                                               new_dispersion_degree=dispersion_degree)

            discrete_x = self.__predation_update(discrete_x_old=discrete_x, continuous_x_old=x)
            # # 均衡算子
            # discrete_x = self.__allocation_method_update(x=discrete_x)
            # 边界检查
            discrete_x = self.__check_solution_validation(discrete_x)
            fitness_array = self.__calculate_fitness(discrete_x)
            fitness_array, index = self.__sort_fitness(fitness_array=fitness_array)
            discrete_x = self.__regenerate_sorted_x_array(x_old=discrete_x, index_old=index)
            x_last_epoch = discrete_x

            last_dispersion_degree = self.__calculate_dispersion_degree(discrete_x)
            # 更新全局最优解
            if global_best_score >= fitness_array[0]:
                global_best_score = fitness_array[0]
                global_best_position[0, :] = discrete_x[0, :]
                # print("更新最优解:{},Cost为:{}".format(global_best_position[0, :], global_best_score[0]))
            self.__best_score_curve[epoch, 0] = copy.copy(global_best_score)
            self.__best_score_position[epoch, :] = copy.copy(global_best_position[0, :])
            if config.SHOW_EPOCH_BEST_RESULT and epoch % config.REMAINDER == 0:
                print("[{}] 第%d代的最优搜索结果为:%.2f,位置:%s,捕食者系数:%.3f".format(ALGORITHM_NAME) % (epoch,
                                                                                          global_best_score,
                                                                                          self.__print_solution(
                                                                                              global_best_position,
                                                                                              decode=True),
                                                                                          self.__predation_coe))
        # self.__describe_best_position(best_position=global_best_position)

        return global_best_score, global_best_position


if __name__ == '__main__':
    parameter_dict = {
        "mu": 1.02,
        "levy_rate": 0.2,
        "beta": 1.5,
        "predation_coe": 0.1
    }

    w_d, t_d = parser_data(case_path=os.path.join("../task_allocation_dataset", "case_2_1.txt"))

    dim = len(w_d) + len(t_d)
    low_boundary = 1 * np.ones((dim, 1))
    up_boundary = (dim - 1) * np.ones((dim, 1))

    dadbo = DiscreteADBO(worker_dict=w_d,
                         simulation_task_dict=t_d,
                         population_size=50,
                         max_iteration=500,
                         lb=low_boundary,
                         ub=up_boundary,
                         role_amount_distribution=[0.2, 0.2, 0.3, 0.3],
                         param_dict=parameter_dict)

    dadbo.optimize()
    dadbo.draw_optimization_curve(is_save=False)
