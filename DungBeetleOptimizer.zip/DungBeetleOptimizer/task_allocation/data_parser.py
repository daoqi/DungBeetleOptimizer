"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:data_parser.py
@Created Time: 2023.05.16
"""
import os


def is_line_including_digit(str_line):
    """
        检查该行字符串中是否包含整数,如果包含返回True,不包含返回False
    :param str_line:
    :return:
    """
    for ch in str_line:
        if ch.isdigit():
            return True
    return False


def parser_data(case_path):
    if not os.path.exists(case_path):
        raise FileNotFoundError("{} can not find.".format(case_path))
    worker_dict = {}
    task_dict = {}
    with open(file=case_path, mode="r") as f:
        found_worker = False
        for line in f.readlines():
            if not is_line_including_digit(line):
                continue
            str_size = len(line.split())
            if str_size == 2:
                worker_id, capacity = line.split()
                worker_id = int(worker_id)
                capacity = float(capacity)
                worker_dict[worker_id] = capacity
            elif str_size == 4:
                task_id, vertex_num, edge_num, priority = line.split()
                task_dict[int(task_id)] = [int(vertex_num), int(edge_num),int(priority)]

    return worker_dict, task_dict


if __name__ == '__main__':
    w_d,t_d = parser_data(case_path=os.path.join("../task_allocation_dataset", "case_2_1.txt"))
    print(w_d)
    print(t_d)