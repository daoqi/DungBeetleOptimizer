"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:test.py
@Created Time: 2023.05.15
"""
import os
import random

import numpy as np

PRIORITY = [0, 1, 2, 3]
random.seed(10010)
np.random.seed(10010)

def evaluate_computational_ability(cpu_score, gpu_score, memory):
    print((cpu_score * gpu_score * memory))
    return min(100, 100 * np.log(1 + (cpu_score * gpu_score * memory) / 1000))


def generate_dataset(worker_number, dataset_size, filepath, case):
    if case == 1:
        if not worker_number < dataset_size:
            raise ValueError(
                "Case 1 worker_number should less than dataset_size, get {} < {}".format(worker_number, dataset_size))
    elif case == 2:
        worker_number = dataset_size
    elif case == 3:
        max_val = max(worker_number, dataset_size)
        worker_number = max_val + np.random.randint(1, 5)

    res = "SIMULATION TASK \nTASK_ID VERTEX_NUM EDGE_NUM PRIORITY\n"
    cnt = 0
    while cnt < dataset_size:
        vertex_num = np.random.randint(low=5, high=101)
        task_priority = np.random.choice(PRIORITY)
        """
            有向无环图n个顶点最多生成n(n-1)/2条边
            如果不存在孤立点，则最少需要n-1条边
            (vertex_num * (vertex_num - 1)) / 2 + 1
            2*(n-1) < n(n-1) When n>2
        """
        edge_num = np.random.randint(low=vertex_num - 1, high=(vertex_num - 1) * 2)
        # print("Simulation task size: Vertex:{}, edge:{}".format(vertex_num, edge_num))
        res += "{} {} {} {}\n".format(cnt + 1, vertex_num, edge_num,task_priority)
        cnt += 1
    node_info = "WORKER\nWORKER_ID COMPUTATIONAL_CAPABILITY\n"
    cnt = 0
    while cnt < worker_number:
        node_computational_capability = np.random.uniform(low=1, high=100)
        temp = "{} {}\n".format(cnt + 1, node_computational_capability)
        node_info += temp
        cnt += 1

    res = node_info + res
    with open(filepath, "w") as f:
        f.write(res)


if __name__ == '__main__':
    # print(evaluate_computational_ability(126045, 39639, 51.2))
    _case = 1
    while _case < 4:
        i = 0
        while i < 10:
            generate_dataset(worker_number=3, dataset_size=10,
                             filepath=os.path.join(r"../task_allocation_dataset",
                                                   "case_{}_{}.txt".format(_case, i + 1)),
                             case=_case)
            i += 1
        _case += 1
