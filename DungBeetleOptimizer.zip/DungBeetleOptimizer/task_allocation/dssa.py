"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:dssa.py
@Created Time: 2023.06.15
"""
import copy
import math
import random
import time

import numpy as np
from configuration import set_global_randomness
from configuration import config
from test_function import *
from configuration import set_global_randomness
from data_parser import parser_data
import os
import matplotlib.pyplot as plt

plt.rc('font', family='Times New Roman')
set_global_randomness()
ALGORITHM_NAME = "DSSA"


class DSSA:
    def __init__(self,
                 worker_dict,
                 simulation_task_dict,
                 population_size: int,
                 max_iteration: int,
                 lb: np.ndarray,
                 ub: np.ndarray,
                 ST=0.6,
                 PD=0.7,
                 SD=0.2
                 ):
        """

        :param func: 优化函数
        :param n_dim: 优化目标个数
        :param population_size: 种群规模
        :param max_iteration: 最大迭代次数
        :param lb: 下界
        :param ub: 上界
        :param ST: 预警值
        :param PD: 发现者比例
        :param SD: 意识到危险的麻雀比例
        """
        self.__worker_dict = worker_dict
        self.__simulation_task_dict = simulation_task_dict
        self.__n_dim = len(simulation_task_dict) + len(worker_dict)
        self.__population_size = population_size
        self.__max_iteration = max_iteration
        self.__lb = lb
        self.__ub = ub
        self.__population_size = population_size  # number of particles
        self.__PD_number = int(self.__population_size * PD)
        self.__SD_number = int(self.__population_size * SD)
        self.__ST = ST
        self.__max_iteration = max_iteration  # max iteration
        # 迭代曲线
        self.__best_score_curve = np.zeros((self.__max_iteration, 1))
        self.__best_score_position = np.zeros((self.__max_iteration, self.__n_dim))

    def export_optimization_procedure(self, step=1):
        """
            导出优化过程中的最优解和其函数值
        :return:
        """
        return self.__best_score_position[::step], self.__best_score_curve[::step]

    def __initialize_population(self):
        row_num = self.__population_size
        worker_num = len(self.__worker_dict)
        task_num = len(self.__simulation_task_dict)
        col_num = task_num + worker_num
        res_solution = np.zeros(shape=(row_num, col_num))
        for i in range(0, row_num):
            task_id_list = list(self.__simulation_task_dict.keys())
            for j in range(0, task_num):
                pop_task_id = np.random.choice(task_id_list, replace=False)
                res_solution[i, j] = pop_task_id
                task_id_list.remove(pop_task_id)
            surplus_task = copy.deepcopy(task_num)
            for j in range(task_num, col_num):
                if j == col_num - 1:
                    # 以保证 sum(res[i,task_num:col_num-1]) == task_num
                    res_solution[i, col_num - 1] = surplus_task
                    break
                allocation_num = np.random.randint(0, surplus_task)
                res_solution[i, j] = allocation_num
                surplus_task -= allocation_num

        return res_solution

    def __decode_to_discrete(self, discrete_x_old: np.ndarray, continuous_x_old):
        """
            应用DSSA中的离散方式将经过函数运算后的连续值映射回离散值
        :param discrete_x_old:
        :param continuous_x_old:
        :return:
        """
        assert discrete_x_old.shape == continuous_x_old.shape

        task_num = len(self.__simulation_task_dict)
        row_n = continuous_x_old.shape[0]
        res_x = np.zeros((row_n, self.__n_dim), dtype="int")
        # if self.__check_discrete_x(discrete_x_old, "discrete old") is False:
        #     exit()
        sorted_discrete_x_old = np.sort(discrete_x_old[:, :task_num], axis=1)
        sorted_continuous_x = np.sort(continuous_x_old[:, :task_num], axis=1)
        for row_index in range(0, self.__population_size):
            vis = np.full(shape=(1, task_num), fill_value=False)
            for col_index in range(0, task_num):
                to_search_target = continuous_x_old[row_index, col_index]
                for search_j in range(0, task_num):
                    elem_in_sorted_continuous_x = sorted_continuous_x[row_index, search_j]
                    if math.isclose(to_search_target, elem_in_sorted_continuous_x) and (not vis[0, search_j]):
                        res_x[row_index, col_index] = sorted_discrete_x_old[row_index, search_j]
                        vis[0, search_j] = True
                        break
                    else:
                        continue
            for assignment_j in range(task_num, self.__n_dim):
                res_x[row_index, assignment_j] = discrete_x_old[row_index, assignment_j]
        # if self.__check_discrete_x(res_x, "discrete") is False:
        #     exit()
        return res_x

    def __gen_allocation_list_from_solution(self, x: np.ndarray):
        """
        :param x:
        :return: list [[],...,[]]
        """

        res_allocation_list = []
        task_number = len(self.__simulation_task_dict)
        worker_number = len(self.__worker_dict)
        for i in range(0, x.shape[0]):
            s = 0
            allocation_list = []
            for j in range(1, worker_number + 1):
                worker_allocation_number = int(x[i, task_number + (j - 1)])
                worker_load = x[i, s:s + worker_allocation_number]
                s += worker_allocation_number
                allocation_list.append(worker_load)
            res_allocation_list.append(allocation_list)
        return res_allocation_list

    def __sum_complexity(self, x, c0=0.5, c1=0.5):
        """

        :param x: []
        :param c0:
        :param c1:
        :return:
        """
        total_sum = 0
        total_priority_sum = 0
        if x.shape[0] <= 0:
            return 0, 0
        for task_index, task_id in enumerate(x):
            task_id = int(task_id)
            vertex_num = self.__simulation_task_dict[task_id][0]
            edge_num = self.__simulation_task_dict[task_id][1]
            priority = self.__simulation_task_dict[task_id][2]
            total_priority_sum += (priority * task_index)
            total_sum += (c0 * vertex_num + c1 * edge_num)
        return total_sum, total_priority_sum

    def __evaluate_total_cost(self, x):
        """
            评估一组分配方式的最大代价
        :param x: allocation result [[],...,[]]
        :return:
        """
        res_list = []
        worker_num = len(self.__worker_dict)

        for worker_index in range(0, worker_num):
            worker_id = worker_index + 1
            worker_capacity = self.__worker_dict[worker_id]
            group_complexity, pc = self.__sum_complexity(x[worker_index], c0=0.5, c1=0.5)
            dispersion_cost = np.std([len(elem) for elem in x])

            cost = (group_complexity / worker_capacity) + dispersion_cost + pc
            # print("Allocation result:{},cost:{},ECT:{},PC:{},DC:{}".format(
            #     x, cost,
            #     (group_complexity / worker_capacity),
            #     pc,
            #     dispersion_cost))
            res_list.append(cost)

        # print("Allocation cost: ",res_list)
        return max(res_list)

    def __calculate_fitness(self, x: np.ndarray) -> np.ndarray:
        """
            计算任务分配的适应度函数,在一组解中任务id应该是唯一的
        :param x:
        :return:
        """
        row_num = x.shape[0]
        fitness = np.zeros([row_num, 1])
        allocation_result = self.__gen_allocation_list_from_solution(x)

        for i in range(0, row_num):
            try:
                fitness[i] = self.__evaluate_total_cost(allocation_result[i])
                # print("计算:{},适应度:{}".format(x[i, :],fitness[i]))
            except KeyError as e:
                print("[__calculate_fitness] Error index:{}".format(i))
                print("[__calculate_fitness] Error allocation result:{}".format(allocation_result[i]))
                print(x[i, :])
                print(e)
                exit()
        return fitness

    def __sort_fitness(self, fitness_array) -> tuple:
        sorted_fitness = np.sort(fitness_array, axis=0)
        index = np.argsort(fitness_array, axis=0)
        return sorted_fitness, index

    def __regenerate_sorted_x_array(self, x_old: np.ndarray, index_old: np.ndarray) -> np.ndarray:
        """
            适应度函数越小的解，在新的解集中的位置越靠近第0行
        """
        row_num = x_old.shape[0]
        x_new = np.zeros(x_old.shape)
        for i in range(0, row_num):
            x_new[i, :] = x_old[index_old[i], :]
        return x_new

    def __PD_update(self, x):
        """
        麻雀发现者勘探更新
        :param x:
        :return:
        """
        task_num = len(self.__simulation_task_dict)
        XW_new = copy.copy(x)
        r2 = random.random()
        for j in range(0, self.__PD_number):
            if r2 < self.__ST:
                XW_new[j, 0:task_num] = x[j, 0:task_num] * np.exp(-j / (random.random() * self.__max_iteration))
            else:
                XW_new[j, 0:task_num] = x[j, 0:task_num] + np.random.randn() * np.ones([1, task_num])
        return XW_new

    def __JDUpdate(self, x):
        x_new = copy.deepcopy(x)
        task_num = len(self.__simulation_task_dict)
        for j in range(self.__PD_number + 1, self.__population_size):
            if j > (self.__population_size - self.__PD_number) / 2 + self.__PD_number:
                x_new[j, 0:task_num] = np.random.randn() * np.exp((x[-1, 0:task_num] - x[j, 0:task_num]) / j ** 2)
            else:
                # 产生-1，1的随机数
                A = np.ones([task_num, 1])
                for a in range(task_num):
                    if random.random() > 0.5:
                        A[a] = -1
                AA = np.dot(A, np.linalg.inv(np.dot(A.T, A)))
                x_new[j, 0:task_num] = x[1, 0:task_num] + np.abs(x[j, 0:task_num] - x[1, 0:task_num]) * AA.T
        return x_new

    def __SDUpdate(self, x, fitness, global_best_score):
        x_new = copy.copy(x)
        task_num = len(self.__simulation_task_dict)
        temp = range(self.__population_size)
        rand_index = random.sample(temp, self.__population_size)
        SD_choose_index = rand_index[0:self.__SD_number]
        for j in range(self.__SD_number):
            if fitness[SD_choose_index[j]] > global_best_score:
                x_new[SD_choose_index[j], 0:task_num] = x[0, 0:task_num] + np.random.randn() * np.abs(
                    x[SD_choose_index[j], 0:task_num] - x[1, 0:task_num])
            elif fitness[SD_choose_index[j]] == global_best_score:
                k = 2 * random.random() - 1
                x_new[SD_choose_index[j], 0:task_num] = x[SD_choose_index[j], 0:task_num] + k * (
                        np.abs(x[SD_choose_index[j], 0:task_num] - x[-1, 0:task_num]) / (
                        fitness[SD_choose_index[j]] - fitness[-1] + 10E-8))
        return x_new

    def __check_solution_validation(self, x: np.ndarray):
        """
            用于判断解集是否合法
                1. 任务列表中的task id 不可缺失，重复
                2. 分配方式中服务器的任务分配之和必须是任务总数量
        :param x:
        :return:
        """
        reinitialize_individual_set = set()
        task_num = len(self.__simulation_task_dict)
        for i in range(0, self.__population_size):
            task_check_dict = {}
            for j in range(0, task_num):
                k = int(x[i, j])
                if k > task_num or k < 1:
                    reinitialize_individual_set.add(i)
                if k not in task_check_dict.keys():
                    task_check_dict[k] = 1
                else:
                    task_check_dict[k] += 1
            for key in list(task_check_dict.keys()):
                val = task_check_dict[key]
                if val != 1:
                    reinitialize_individual_set.add(i)
            if int(sum(x[i, task_num:])) != task_num:
                reinitialize_individual_set.add(i)
        # 重新初始化
        col_num = len(self.__simulation_task_dict) + len(self.__worker_dict)
        for i in reinitialize_individual_set:
            task_id_list = list(self.__simulation_task_dict.keys())
            for j in range(0, task_num):
                pop_task_id = np.random.choice(task_id_list, replace=False)
                x[i, j] = pop_task_id
                task_id_list.remove(pop_task_id)
            surplus_task = copy.deepcopy(task_num)
            for j in range(task_num, col_num):
                if j == col_num - 1:
                    # 以保证 sum(res[i,task_num:col_num-1]) == task_num
                    x[i, col_num - 1] = surplus_task
                    break
                allocation_num = np.random.randint(0, surplus_task)
                x[i, j] = allocation_num
                surplus_task -= allocation_num
        return x

    def __print_solution(self, x: np.ndarray, decode=False):
        task_num = len(self.__simulation_task_dict)
        worker_num = len(self.__worker_dict)
        if decode is False:
            for i in range(0, x.shape[0]):
                for j in range(0, task_num):
                    if j == task_num - 1:
                        print(int(x[i, j]), end="")
                    else:
                        print(int(x[i, j]), end=" , ")

                for j in range(task_num, task_num + worker_num):
                    if j == task_num:
                        print(" | {},".format(x[i, j]), end="")
                    else:
                        print("{},".format(x[i, j]), end="")
                print()
        else:
            x = x.reshape((1, self.__n_dim))
            res = self.__gen_allocation_list_from_solution(x)
            res_str = ""
            for row in range(0, x.shape[0]):
                for index, allocation_list in enumerate(res[row]):
                    res_str += " Allocation {}: {}".format(index + 1, allocation_list)
            return res_str

    def __allocation_method_update_crossover(self, discrete_x, crossover_rate=0.6, m=2):
        """
            使用crossover进行负载均衡
        :param discrete_x:
        :param crossover_rate:
        :param m: 交叉点个数
        :return:
        """
        task_num = len(self.__simulation_task_dict)
        server_num = len(self.__worker_dict)
        for i in range(0, self.__population_size):
            child_chromosome = discrete_x[i, :].reshape(1, self.__n_dim)
            if np.random.randn() < crossover_rate:
                mother_chromosome = \
                    discrete_x[np.random.randint(low=0, high=self.__population_size), :].reshape(1, self.__n_dim)
                for cnt in range(m):
                    cross_point_a = np.random.randint(low=server_num, high=self.__n_dim)
                    cross_point_b = np.random.randint(low=cross_point_a, high=self.__n_dim)
                    # print("Cnt:{},Cross point a:{}, cross point b:{}".format(cnt,cross_point_a,cross_point_b))
                    child_chromosome[0, cross_point_a:cross_point_b] = mother_chromosome[0, cross_point_a:cross_point_b]
                discrete_x[i, :] = child_chromosome[0, :]
        return discrete_x

    def draw_optimization_curve(self, is_save=True, file_str=""):
        x = [i for i in range(0, self.__best_score_curve.shape[0])]
        y = self.__best_score_curve[:, 0]
        plt.title("Optimization Curve(DSSA)")
        # if self.__best_score_curve.all() > 0.0:
        #     plt.yscale("log")
        plt.plot(x, y, linestyle="-", label="DSSA")
        plt.xlabel("Epoch")
        plt.ylabel("Current epoch best score")
        plt.legend()
        if not is_save:
            plt.show()
        else:
            if len(file_str) == 0:
                file_str = time.strftime("%Y-%m-%d %H-%M-%S", time.localtime(time.time()))
            plt.savefig(os.path.join(config.IMAGE_SAVING_PATH, "DSSA" + file_str),
                        dpi=1200,
                        bbox_inches="tight",
                        pad_inches=0.0)

    def __allocation_method_update(self, x: np.ndarray):
        """
            更新服务器分配方式
        :param x: (pop size,num of tasks + num of servers)
        :return:
        """

        task_num = len(self.__simulation_task_dict)
        worker_num = len(self.__worker_dict)
        k = math.ceil(worker_num * 0.25)
        for i in range(0, self.__population_size):
            alpha = np.random.rand()
            if 0 < alpha < 0.5:
                k_max_index_list = np.argsort(x[i, task_num:])[-k:]
                k_min_index_list = np.argsort(x[i, task_num:])[0:k]
                for index in range(0, k):
                    if x[i, task_num + k_max_index_list[index]] > 1:
                        x[i, task_num + k_max_index_list[index]] -= 1
                        x[i, task_num + k_min_index_list[index]] += 1
            if alpha > 0.9:
                choice_num_a = np.random.choice(x[i, task_num:])
                choice_num_b = np.random.choice(x[i, task_num:])
                if choice_num_a != choice_num_b:
                    index_a = np.random.randint(low=task_num, high=self.__n_dim)
                    index_b = np.random.randint(low=task_num, high=self.__n_dim)
                    if index_a != index_b:
                        x[i, index_a], x[i, index_b] = x[i, index_b], x[i, index_a]

        return x

    def optimize(self):
        print("{} starts to work!".format(ALGORITHM_NAME))
        discrete_x = self.__initialize_population()
        fitness_array = self.__calculate_fitness(discrete_x)
        fitness_array, index = self.__sort_fitness(fitness_array=fitness_array)
        discrete_x = self.__regenerate_sorted_x_array(x_old=discrete_x, index_old=index)
        discrete_x_w = copy.copy(discrete_x)
        global_best_score = fitness_array[0]

        global_best_position = np.zeros((1, self.__n_dim))
        global_best_position[0, :] = discrete_x[0, :]

        global_worst_score = fitness_array[-1]
        global_worst_position = np.zeros((1, self.__n_dim))
        global_worst_position[0, :] = discrete_x[-1, :]

        for epoch in range(0, self.__max_iteration):
            best_f = fitness_array[0]
            continuous_x = self.__PD_update(discrete_x_w)
            continuous_x = self.__JDUpdate(continuous_x)
            discrete_x = self.__decode_to_discrete(discrete_x_old=discrete_x, continuous_x_old=continuous_x)
            fitness_array = self.__calculate_fitness(discrete_x)
            continuous_x = self.__SDUpdate(discrete_x, fitness_array, best_f)
            discrete_x = self.__decode_to_discrete(discrete_x_old=discrete_x, continuous_x_old=continuous_x)

            discrete_x = self.__allocation_method_update_crossover(discrete_x)

            discrete_x = self.__check_solution_validation(discrete_x)
            fitness_array = self.__calculate_fitness(discrete_x)
            fitness_array, index = self.__sort_fitness(fitness_array=fitness_array)
            discrete_x = self.__regenerate_sorted_x_array(x_old=discrete_x, index_old=index)

            # 更新全局最优解
            if global_best_score >= fitness_array[0]:
                global_best_score = fitness_array[0]
                global_best_position[0, :] = discrete_x[0, :]
                # print("更新最优解:{},Cost为:{}".format(global_best_position[0, :], global_best_score[0]))
            self.__best_score_curve[epoch, 0] = copy.copy(global_best_score)
            self.__best_score_position[epoch, :] = copy.copy(global_best_position[0, :])
            if config.SHOW_EPOCH_BEST_RESULT and epoch % config.REMAINDER == 0:
                print("[{}] 第%d代的最优搜索结果为:%.2f,位置:%s".format(ALGORITHM_NAME) % (epoch,
                                                                               global_best_score,
                                                                               self.__print_solution(
                                                                                   global_best_position,
                                                                                   decode=True),
                                                                               ))
            if global_best_score >= fitness_array[0]:
                global_best_score = fitness_array[0]
                global_best_position[0, :] = discrete_x[0, :]
            self.__best_score_curve[epoch, 0] = copy.copy(global_best_score)
            self.__best_score_position[epoch, :] = copy.copy(global_best_position[0, :])

        # print(global_best_score,global_best_position)
        return global_best_score, global_best_position


if __name__ == '__main__':
    w_d, t_d = parser_data(case_path=os.path.join("../task_allocation_dataset", "case_1_6.txt"))

    dim = len(w_d) + len(t_d)
    low_boundary = 1 * np.ones((dim, 1))
    up_boundary = (dim - 1) * np.ones((dim, 1))

    dssa = DSSA(worker_dict=w_d,
                simulation_task_dict=t_d,
                population_size=30,
                max_iteration=500,
                lb=low_boundary,
                ub=up_boundary,
                ST=0.6,
                PD=0.7,
                SD=0.2)

    _best_score, _best_position = dssa.optimize()
    print(_best_score)
    print(_best_position)
    # dssa.draw_optimization_curve(is_save=False)
