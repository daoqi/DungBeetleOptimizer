"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:capacity_calculator.py
@Created Time: 2023.06.12
"""

import numpy as np

cpu_score = np.array([3.4, 2.7, 2.59, 3.1, 6.0, 3.4, 4.5, 5.5,4.5])
gpu_score = np.array([10.1, 9.1, 2.3, 34.1, 35.7, 12.8, 14.1, 16.31,29.8])
memory_score = np.array([19.2, 17, 21.3, 21.3, 44.8, 17, 38.4, 41.6,25.6])


def norm_x(x: np.ndarray):
    res = (x - np.min(x)) / (np.max(x) - np.min(x))
    return res


def weight(cpu_x, gpu_x, memory_x, w1=0.3, w2=0.4, w3=0.3):
    score = w1 * cpu_x + w2 * gpu_x + w3 * memory_x
    return score


def calc_capability(score):
    res = (score - np.min(score)) * 99 / (np.max(score) - np.min(score)) + 1
    return res


if __name__ == '__main__':
    cpu_n = norm_x(cpu_score)
    gpu_n = norm_x(gpu_score)
    memory_n = norm_x(memory_score)

    s = weight(cpu_x=cpu_n,
               gpu_x=gpu_n,
               memory_x=memory_n,
               w1=0.3, w2=0.4, w3=0.3)

    print(calc_capability(s))
