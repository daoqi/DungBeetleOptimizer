"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:sparrow_search_algorithm.py
@Created Time: 2023.04.18
"""
import copy
import random
import time

import numpy as np
from configuration import set_global_randomness
from configuration import config
from test_function import *
from configuration import set_global_randomness

set_global_randomness()


class SparrowSearchAlgorithm:
    def __init__(self, func: callable,
                 n_dim: int,
                 population_size: int,
                 max_iteration: int,
                 lb: np.ndarray,
                 ub: np.ndarray,
                 ST=0.6,
                 PD=0.7,
                 SD=0.2
                 ):
        """

        :param func: 优化函数
        :param n_dim: 优化目标个数
        :param population_size: 种群规模
        :param max_iteration: 最大迭代次数
        :param lb: 下界
        :param ub: 上界
        :param ST: 预警值
        :param PD: 发现者比例
        :param SD: 意识到危险的麻雀比例
        """
        self.__func = func
        self.__n_dim = n_dim  # dimension of particles, which is the number of variables of func
        self.__lb = lb
        self.__ub = ub
        self.__population_size = population_size  # number of particles
        self.__PD_number = int(self.__population_size * PD)
        self.__SD_number = int(self.__population_size * SD)
        self.__ST = ST
        self.__max_iteration = max_iteration  # max iteration
        # 迭代曲线
        self.__best_score_curve = np.zeros((self.__max_iteration, 1))
        self.__best_score_position = np.zeros((self.__max_iteration, self.__n_dim))

    def __initialize_population(self):
        x = np.zeros([self.__population_size, self.__n_dim])
        for i in range(self.__population_size):
            for j in range(self.__n_dim):
                x[i, j] = np.random.rand() * (self.__ub[j] - self.__lb[j]) + self.__lb[j]
        return x

    def export_optimization_procedure(self):
        """
            导出优化过程中的最优解和其函数值,(最优解,最优函数值)
        :return:
        """
        return self.__best_score_position, self.__best_score_curve

    def __calculate_fitness(self, x: np.ndarray) -> np.ndarray:
        row_num = x.shape[0]
        fitness = np.zeros([row_num, 1])
        for i in range(0, row_num):
            fitness[i] = self.__func(x[i, :].reshape(1, self.__n_dim))
            # print("计算:{},适应度:{}".format(x[i, :],fitness[i]))
        return fitness

    def __sort_fitness(self, fitness_array) -> tuple:
        sorted_fitness = np.sort(fitness_array, axis=0)
        index = np.argsort(fitness_array, axis=0)
        return sorted_fitness, index

    def __regenerate_sorted_x_array(self, x_old: np.ndarray, index_old: np.ndarray) -> np.ndarray:
        """
            适应度函数越小的解，在新的解集中的位置越靠近第0行
        """
        row_num = x_old.shape[0]
        x_new = np.zeros(x_old.shape)
        for i in range(0, row_num):
            x_new[i, :] = x_old[index_old[i], :]
        return x_new

    def __PD_update(self, x):
        """
        麻雀发现者勘探更新
        :param x:
        :return:
        """
        XW_new = copy.copy(x)
        r2 = random.random()
        for j in range(0, self.__PD_number):
            if r2 < self.__ST:
                XW_new[j, :] = x[j, :] * np.exp(-j / (random.random() * self.__max_iteration))
            else:
                XW_new[j, :] = x[j, :] + np.random.randn() * np.ones([1, self.__n_dim])
        return XW_new

    def __JDUpdate(self, x):
        x_new = copy.deepcopy(x)
        for j in range(self.__PD_number + 1, self.__population_size):
            if j > (self.__population_size - self.__PD_number) / 2 + self.__PD_number:
                x_new[j, :] = np.random.randn() * np.exp((x[-1, :] - x[j, :]) / j ** 2)
            else:
                # 产生-1，1的随机数
                A = np.ones([self.__n_dim, 1])
                for a in range(self.__n_dim):
                    if random.random() > 0.5:
                        A[a] = -1
                AA = np.dot(A, np.linalg.inv(np.dot(A.T, A)))
                x_new[j, :] = x[1, :] + np.abs(x[j, :] - x[1, :]) * AA.T
        return x_new

    def __SDUpdate(self, x, fitness, global_best_score):
        x_new = copy.copy(x)
        temp = range(self.__population_size)
        rand_index = random.sample(temp, self.__population_size)
        SD_choose_index = rand_index[0:self.__SD_number]
        for j in range(self.__SD_number):
            if fitness[SD_choose_index[j]] > global_best_score:
                x_new[SD_choose_index[j], :] = x[0, :] + np.random.randn() * np.abs(x[SD_choose_index[j], :] - x[1, :])
            elif fitness[SD_choose_index[j]] == global_best_score:
                k = 2 * random.random() - 1
                x_new[SD_choose_index[j], :] = x[SD_choose_index[j], :] + k * (
                        np.abs(x[SD_choose_index[j], :] - x[-1, :]) / (
                        fitness[SD_choose_index[j]] - fitness[-1] + 10E-8))
        return x_new

    def __border_check(self, x):
        for i in range(self.__population_size):
            for j in range(self.__n_dim):
                if x[i, j] > self.__ub[j]:
                    x[i, j] = self.__ub[j]
                elif x[i, j] < self.__lb[j]:
                    x[i, j] = self.__lb[j]
        return x

    def optimize(self):
        print("Sparrow Search Algorithm starts to work!")
        x = self.__initialize_population()
        # variances = np.var(x, axis=0)
        # total_variance = np.sum(variances)
        # print(total_variance)
        # print(x)
        # exit()
        fitness_array = self.__calculate_fitness(x)
        fitness_array, index = self.__sort_fitness(fitness_array=fitness_array)
        x = self.__regenerate_sorted_x_array(x_old=x, index_old=index)
        x_w = copy.copy(x)
        global_best_score = fitness_array[0]

        global_best_position = np.zeros((1, self.__n_dim))
        global_best_position[0, :] = x[0, :]

        global_worst_score = fitness_array[-1]
        global_worst_position = np.zeros((1, self.__n_dim))
        global_worst_position[0, :] = x[-1, :]

        for epoch in range(0, self.__max_iteration):
            best_f = fitness_array[0]
            x = self.__PD_update(x_w)
            x = self.__JDUpdate(x)
            x = self.__SDUpdate(x, fitness_array, best_f)
            x = self.__border_check(x)
            fitness_array = self.__calculate_fitness(x)
            fitness_array, index = self.__sort_fitness(fitness_array=fitness_array)
            x = self.__regenerate_sorted_x_array(x_old=x, index_old=index)
            if global_best_score >= fitness_array[0]:
                global_best_score = fitness_array[0]
                global_best_position[0, :] = x[0, :]
            self.__best_score_curve[epoch, 0] = copy.copy(global_best_score)
            self.__best_score_position[epoch, :] = copy.copy(global_best_position[0, :])

            if config.SHOW_EPOCH_BEST_RESULT and epoch % config.REMAINDER == 0:
                print("第%d代的最优搜索结果为:%.2f,位置:%s" % (epoch, global_best_score, global_best_position))
        # print(global_best_score,global_best_position)
        return global_best_score, global_best_position


if __name__ == '__main__':
    dim = 30
    low_boundary = -100 * np.ones((dim, 1))
    up_boundary = 100 * np.ones((dim, 1))
    ssa = SparrowSearchAlgorithm(func=step_f,
                                 n_dim=dim,
                                 population_size=100,
                                 max_iteration=1000,
                                 lb=low_boundary,
                                 ub=up_boundary,
                                 ST=0.6,
                                 PD=0.7,
                                 SD=0.2)
    best_score, best_position = ssa.optimize()
    print(best_score, best_position)
