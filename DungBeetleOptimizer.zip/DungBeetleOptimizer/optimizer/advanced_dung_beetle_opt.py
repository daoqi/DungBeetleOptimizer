"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:dung_beetle_opt.py
@Created Time: 2023.04.15
"""
import copy
import math
import os
import time
import matplotlib.pyplot as plt
import numpy as np
from numba import jit
from globals import DungBeetleRoleEnum, util
from globals import check_amount_distribution
from configuration import set_global_randomness, config
from globals.chaotic_mapping import SingerMapping, LogisticMapping
from test_function import *

plt.rc('font', family='Times New Roman')
set_global_randomness()


class AdvancedDungBeetleOptimizer:
    """
        Contribution only_chaotic_mapping: 在初始化时,引入混沌映射,让初始种群分布更加分散
        Contribution 2: 在进入下一轮迭代前,针对部分适应度差的解应用Levy flight策略
    """

    def __init__(self, func: callable,
                 n_dim: int,
                 population_size: int,
                 max_iteration: int,
                 lb: np.ndarray,
                 ub: np.ndarray,
                 role_amount_distribution: list,
                 param_dict: dict = None):
        """
        :param func: 优化目标(适应度函数)
        :param n_dim: 优化参数个数
        :param population_size: 种群规模
        :param max_iteration: 最大迭代次数
        :param lb: 迭代范围下界
        :param ub: 迭代范围上界
        :param role_amount_distribution: 在蜣螂种群中四种角色的数量分布,加和为1
        :param param_dict: 其他优化参数
        """
        self.__func = func
        self.__n_dim = n_dim
        self.__population_size = population_size
        self.__max_iteration = max_iteration
        self.__lb = lb
        self.__ub = ub
        self.__role_ub = [0, 0, 0, 0]
        self.__best_score_curve = np.zeros((self.__max_iteration, 1))
        self.__best_score_position = np.zeros((self.__max_iteration, self.__n_dim))
        self.__param_dict = param_dict
        if "predation_coe" not in param_dict:
            self.__predation_coe = 0.2
        else:
            self.__predation_coe = param_dict["predation_coe"]
        if check_amount_distribution(role_amount_distribution):
            self.__amount_distribution = role_amount_distribution
            self.__gen_role_range()
            # print("四种角色的蜣螂下标范围: ", self.__role_ub)
        else:
            raise ValueError("蜣螂种群的角色分布不满足定义,错误分布:{}".format(role_amount_distribution))

    def export_optimization_procedure(self):
        """
            导出优化过程中的最优解和其函数值
        :return:
        """
        return self.__best_score_position, self.__best_score_curve

    def draw_optimization_curve(self, is_save=True, file_str=""):
        x = [i for i in range(0, self.__best_score_curve.shape[0])]
        y = self.__best_score_curve[:, 0]
        plt.title("Optimization Curve(advanced-with predator)")
        if self.__best_score_curve.all() > 0.0:
            plt.yscale("log")
        plt.plot(x, y)
        plt.xlabel("Epoch")
        plt.ylabel("Current epoch best score")
        if not is_save:
            plt.show()
        else:
            if len(file_str) == 0:
                file_str = time.strftime("%Y-%m-%d %H-%M-%S", time.localtime(time.time()))
            plt.savefig(os.path.join(config.IMAGE_SAVING_PATH, "AdvancedDungBeetleOpt-with predator" + file_str))

    def __gen_role_range(self):
        """
            根据数量分布分别依次生成滚球蜣螂，产卵蜣螂,觅食蜣螂,偷窃蜣螂这四种角色的下标范围
        """
        last_num = 0
        for index in range(0, len(self.__amount_distribution)):
            last_num = last_num + round(self.__population_size * self.__amount_distribution[index])
            self.__role_ub[index] = last_num

    def __check_border(self, x):
        """
            x的值超出了搜索范围
        :param x:
        :return:
        """
        for i in range(self.__population_size):
            for j in range(self.__n_dim):
                if x[i, j] > self.__ub[j]:
                    x[i, j] = self.__ub[j]
                elif x[i, j] < self.__lb[j]:
                    x[i, j] = self.__lb[j]
        return x

    def __initialize_population(self):
        """
            Contribution only_chaotic_mapping: chaotic mapping,
            disperse the distribution of the initial population to prevent falling into a local optimal solution
        :return:
        """

        x = np.zeros([self.__population_size, self.__n_dim])
        for i in range(self.__population_size):
            for j in range(self.__n_dim):
                x[i, j] = np.random.rand() * (self.__ub[j] - self.__lb[j]) + self.__lb[j]
        temp_x = x
        singer_mapping = SingerMapping(x=x, mu=self.__param_dict["mu"])
        x = singer_mapping.generate_mapping_result()
        # TODO:还原那些超出搜索范围的解
        for i in range(0, self.__population_size):
            for j in range(self.__n_dim):
                if not self.__lb[j] <= x[i, j] <= self.__ub[j]:
                    x[i, j] = temp_x[i, j]
        return x

    def __roll_ball_update(self, x, x_last_epoch, global_worst_position):
        """
            滚球与跳舞行为
        """
        x_new = copy.copy(x)
        eta = np.random.rand(1)
        col_num = x.shape[1]
        b = 0.3
        for i in range(0, self.__role_ub[DungBeetleRoleEnum.ROLL_BALL_DUNG_BEETLE.value]):
            if eta < 0.9:
                alpha = np.random.rand(1)
                if alpha > 0.1:
                    alpha = 1
                else:
                    alpha = -1

                x_new[i, :] = x[i, :] + b * \
                              np.abs(x[i, :] - global_worst_position[0, :]) + alpha * 0.1 * (
                                  x_last_epoch[i, :])  # Equation(1)
            else:
                # dance
                theta = np.random.randint(180, size=1)
                if theta == 0 or theta == 90 or theta == 180:
                    for j in range(0, col_num):
                        x_new[i, j] = x[i, j]
                temp_theta = theta * np.pi / 180
                x_new[i, :] = x[i, :] + math.tan(temp_theta) * np.abs(x[i, :] - x_last_epoch[i, :])  # Equation(2)
        # # 防止产生蜣螂位置超出解的约束空间
        # for i in range(self.__role_ub[DungBeetleRoleEnum.ROLL_BALL_DUNG_BEETLE.value]):
        #     for j in range(self.__n_dim):
        #         x_new[i, j] = np.clip(x_new[i, j], self.__lb[j], self.__ub[j])
        return x_new

    def __greedy_roll_ball_update(self, x, x_last_epoch, global_worst_position, greedy_time=3):
        """

        :param x:
        :param x_last_epoch:
        :param global_worst_position:
        :param greedy_time:
        :return:
        """
        new_x = self.__roll_ball_update(x=x, x_last_epoch=x_last_epoch, global_worst_position=global_worst_position)
        x_last_epoch = new_x
        fitness_array = self.__calculate_fitness(new_x)
        sorted_fitness, index = self.__sort_fitness(fitness_array=fitness_array)
        second_sorted_x = self.__regenerate_sorted_x_array(x_old=new_x, index_old=index)
        second_global_worst_position = np.zeros((1, self.__n_dim))
        second_global_worst_position[0, :] = new_x[-1, :]
        cnt = 0
        while cnt < greedy_time:
            # print("{} < {}".format(sorted_fitness[0],fitness_array[0]))
            second_x = self.__roll_ball_update(x=second_sorted_x, x_last_epoch=x_last_epoch,
                                               global_worst_position=second_global_worst_position)
            x_last_epoch = second_x
            fitness_array = self.__calculate_fitness(second_x)
            sorted_fitness, index = self.__sort_fitness(fitness_array=fitness_array)
            second_sorted_x = self.__regenerate_sorted_x_array(x_old=second_x, index_old=index)
            second_global_worst_position[0, :] = second_x[-1, :]
            cnt += 1
        return new_x

    def __brood_ball_update(self, x, epoch, fitness_array):
        """
            产卵(繁殖)行为
        """
        x_new = copy.copy(x)
        r = 1 - epoch / self.__max_iteration
        # 找到x最小适应度的索引
        best_index = np.argmin(fitness_array)
        # 找到最优的蜣螂位置
        best_x = x[best_index, :]
        lb_star = best_x * (1 - r)
        ub_star = best_x * (1 + r)
        for row_i in range(0, self.__n_dim):
            # Equation(3)
            lb_star[row_i] = max(lb_star[row_i], self.__lb[row_i])
            ub_star[row_i] = max(ub_star[row_i], self.__ub[row_i])
        for i in range(self.__role_ub[DungBeetleRoleEnum.ROLL_BALL_DUNG_BEETLE.value] + 1,
                       self.__role_ub[DungBeetleRoleEnum.BROOD_BALL_DUNG_BEETLE.value]):
            # Equation(4)
            x_new[i, :] = best_x + (np.random.rand(1, self.__n_dim)) * (
                    x[i, :] - lb_star + (np.random.rand(1, self.__n_dim)) * (x[i, :] - ub_star))
            for j in range(self.__n_dim):
                x_new[i, j] = np.clip(x_new[i, j], lb_star[j], ub_star[j])
        return x_new

    def __greedy_brood_ball_update(self, x, epoch, greedy_time=5):
        """
            贪心产卵(繁殖)行为
        """
        greedy_it = 0
        x_new = copy.copy(x)
        fitness_array = self.__calculate_fitness(x)
        while greedy_it < greedy_time:
            r = (1 - (epoch + greedy_it)) / self.__max_iteration
            # 找到x最小适应度的索引
            best_index = np.argmin(fitness_array)
            # 找到最优的蜣螂位置
            best_x = x[best_index, :]
            lb_star = best_x * (1 - r)
            ub_star = best_x * (1 + r)
            for row_i in range(0, self.__n_dim):
                # Equation(3)
                lb_star[row_i] = max(lb_star[row_i], self.__lb[row_i])
                ub_star[row_i] = max(ub_star[row_i], self.__ub[row_i])
            for i in range(self.__role_ub[DungBeetleRoleEnum.ROLL_BALL_DUNG_BEETLE.value] + 1,
                           self.__role_ub[DungBeetleRoleEnum.BROOD_BALL_DUNG_BEETLE.value]):
                # Equation(4)
                x_new[i, :] = best_x + (np.random.rand(1, self.__n_dim)) * (
                        x[i, :] - lb_star + (np.random.rand(1, self.__n_dim)) * (x[i, :] - ub_star))
                for j in range(self.__n_dim):
                    x_new[i, j] = np.clip(x_new[i, j], lb_star[j], ub_star[j])

            fitness_array = self.__calculate_fitness(x)
            sorted_fitness, index = self.__sort_fitness(fitness_array=fitness_array)
            x = self.__regenerate_sorted_x_array(x_old=x, index_old=index)
            x_new = x
            greedy_it += 1
        return x_new

    def __forage_update(self, x, epoch, fitness_array, global_best_position):
        """
            小屎壳郎觅食更新
        """
        x_new = copy.copy(x)
        col_num = x.shape[1]
        r = 1 - epoch / self.__max_iteration
        lbb = global_best_position[0, :] * (1 - r)
        ubb = global_best_position[0, :] * (1 + r)
        for j in range(col_num):
            lbb[j] = np.clip(lbb[j], self.__lb[j], self.__ub[j])  # Equation(5)
            ubb[j] = np.clip(ubb[j], self.__lb[j], self.__ub[j])  # Equation(5)
        for i in range(self.__role_ub[DungBeetleRoleEnum.BROOD_BALL_DUNG_BEETLE.value] + 1,
                       self.__role_ub[DungBeetleRoleEnum.FORAGE_BALL_DUNG_BEETLE.value]):  # Equation(6)
            x_new[i, :] = x[i, :] + (np.random.rand(1, self.__n_dim)) * \
                          (x[i, :] - lbb) + (np.random.rand(1, self.__n_dim)) * \
                          (x[i, :] - ubb)
            for j in range(self.__n_dim):
                x_new[i, j] = np.clip(x_new[i, j], lbb[j], ubb[j])
        return x_new

    def __thieve_update(self, x, epoch, global_best_position, fitness_array):
        """
            偷窃更新
        """
        x_new = copy.copy(x)
        col_num = x.shape[1]
        f_min = np.min(fitness_array)  # 找到x中最小的适应度
        bestIndex = np.argmin(fitness_array)  # 找到x中最小适应度的索引
        best_x = x[bestIndex, :]  # 找到x中具有最有适应度的蜣螂位置
        for i in range(self.__role_ub[DungBeetleRoleEnum.FORAGE_BALL_DUNG_BEETLE.value] + 1,
                       self.__population_size):  # Equation(7)
            x_new[i, :] = global_best_position[0, :] + np.random.randn(1, self.__n_dim) * (
                    np.abs(x[i, :] - global_best_position[0, :]) + np.abs(x[i, :] - best_x)) / 2
            for j in range(self.__n_dim):
                x_new[i, j] = np.clip(x_new[i, j], self.__lb[j], self.__ub[j])
        return x_new

    def __levy_flight(self, last_x, beta=1.5):
        """
            为单一个体添加levy飞行策略
        :param last_x:(1,self.__n_dim)
        :param beta:
        :return:
        """
        res_x = np.zeros(shape=(1, self.__n_dim))
        alpha_u = math.pow((np.math.gamma(1 + beta) * math.sin(math.pi * beta / 2) /
                            (np.math.gamma(((1 + beta) / 2) * beta * math.pow(2, (beta - 1) / 2)))),
                           (1 / beta))
        alpha_v = 1
        for j in range(0, self.__n_dim):
            u = np.random.normal(0, alpha_u, 1)
            v = np.random.normal(0, alpha_v, 1)
            step = u / math.pow(abs(v), (1 / beta))
            res_x[0, j] = last_x[0, j] + step
        return res_x

    def __calculate_fitness(self, x: np.ndarray) -> np.ndarray:
        row_num = x.shape[0]
        fitness = np.zeros([row_num, 1])
        for i in range(0, row_num):
            fitness[i] = self.__func(x[i, :].reshape(1, self.__n_dim))
            # print("计算:{},适应度:{}".format(x[i, :],fitness[i]))
        return fitness

    def __sort_fitness(self, fitness_array) -> tuple:
        sorted_fitness = np.sort(fitness_array, axis=0)
        index = np.argsort(fitness_array, axis=0)
        return sorted_fitness, index

    def __regenerate_sorted_x_array(self, x_old: np.ndarray, index_old: np.ndarray) -> np.ndarray:
        """
            适应度函数越小的解，在新的解集中的位置越靠近第0行
        """
        row_num = x_old.shape[0]
        x_new = np.zeros(x_old.shape)
        for i in range(0, row_num):
            x_new[i, :] = x_old[index_old[i], :]
        return x_new

    def __calculate_dispersion_degree(self, x):
        """
            计算种群离散程度,方差
        :param x:
        :return:
        """
        variances = np.var(x, axis=0)
        total_variance = np.sum(variances)
        return total_variance

    def __modify_predator_coefficient(self, last_dispersion_degree, new_dispersion_degree):
        """
            更新捕食者系数,捕食者系数越大,屎壳郎的被捕食率越高,捕食者系数取决于:
                1. 屎壳郎的种群离散程度
                2. 捕食者的注意程度
            屎壳郎种群离散,且捕食者警惕度低时,降低捕食系数
            屎壳郎种群密集,且捕食者警惕度高时,提高捕食系数
        :param last_dispersion_degree:
        :param new_dispersion_degree:
        :return:
        """
        predator_attention = np.random.randn(1)
        predator_awareness = 0.3
        float_degree = np.random.uniform(0.01, 0.02)
        if self.__predation_coe < 0.0 or self.__predation_coe >= 0.2:
            self.__predation_coe = 0.15
        if new_dispersion_degree > last_dispersion_degree:
            # 种群整体更离散,降低捕食率或者保持不动
            if predator_attention < predator_awareness:
                self.__predation_coe -= float_degree
        else:
            # 种群整体更密集,同时受到了捕食者的关注
            if predator_attention > (1 - predator_awareness):
                self.__predation_coe += float_degree

    def __calculate_p_of_counter_attack(self, i, a=1.0):
        res = math.exp(-a * i / self.__n_dim)
        return res

    def __predate_successful(self,x_old,dead_index):
        """

        :param x_old:
        :param dead_index: 需要被捕食个体的下标
        :return:
        """
        for i in range(0, self.__population_size):
            p_of_counter_attack = self.__calculate_p_of_counter_attack(i, a=1.0)
            alpha = np.random.randn(1)
            if alpha > 0.2:
                # 咬击更新
                pass
            else:
                # 逃跑
                rate = self.__param_dict["levy_rate"]
                beta = self.__param_dict["beta"]
                x_old[i, :] = self.__levy_flight(last_x=x_old[i, :].reshape(1, self.__n_dim), beta=beta)

        fitness_array = self.__calculate_fitness(x_old)
        sorted_fitness, index = self.__sort_fitness(fitness_array=fitness_array)
        x_new = self.__regenerate_sorted_x_array(x_old=x_old, index_old=index)
        for i in range(dead_index, self.__population_size):
            # 屎壳郎被捕食(将这些个体重新进行初始化)-差分演化
            # 1. 从x_new[dead_index,self.__population_size] 中随机抽取三行解
            factor = np.random.uniform()
            row_sequence = np.random.choice(self.__population_size, 3, replace=False, p=None)
            diff_matrix = x_new[row_sequence, :]
            x_new[i, :] = diff_matrix[0, :] + factor * (diff_matrix[1, :] - diff_matrix[2, :])

        fitness_array = self.__calculate_fitness(x_new)
        sorted_fitness, index = self.__sort_fitness(fitness_array=fitness_array)
        x_new = self.__regenerate_sorted_x_array(x_old=x_new, index_old=index)
        return x_new

    def __predate_failure(self,x_old,dead_index):
        for i in range(dead_index,self.__population_size):
            x_old[i, :] = np.random.randn() * np.exp((x_old[-1, :] - x_old[i, :]) / i ** 2)
        return x_old

    def __predation_update(self, x_old):
        """
            捕食更新
        :param x_old:
        :return:
        """
        x_new = x_old
        eta = np.random.randn()
        dead_index = self.__population_size - int(self.__population_size * self.__predation_coe)

        if eta < 0.3:
            # 捕食成功
            x_new = self.__predate_successful(x_old=x_old,dead_index=dead_index)
        else:
            # 捕食失败,屎壳郎心有余悸,抱团更新
            x_new = self.__predate_failure(x_old=x_old,dead_index=dead_index)
        return x_new




    def paint_x_position_and_function(self, lb, ub, step=0.1):
        """
            对于绘制二元函数
            绘制每次迭代的点,在优化目标上的位置
        :return:
        """
        assert self.__n_dim == 2
        x_1 = np.arange(lb, ub, step)
        x_2 = np.arange(lb, ub, step)
        x_1, x_2 = np.meshgrid(x_1, x_2)
        x = np.c_[x_1.ravel(), x_2.ravel()]
        y = self.__calculate_fitness(x).reshape(x_1.shape)

        print(self.__best_score_curve.shape, self.__best_score_position.shape)
        point_x1 = self.__best_score_position[:, 0]
        point_x2 = self.__best_score_position[:, 1]
        point_y = self.__best_score_curve[:, 0]

        # 创建一个三维图形窗口
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')

        # 绘制三维图像
        ax.plot_surface(x_1, x_2, y, cmap='rainbow')
        # 绘制搜索结果
        ax.scatter(point_x1, point_x2, point_y, marker="*")
        # 添加标签和标题
        ax.set_xlabel('x_1')
        ax.set_ylabel('x_2')
        ax.set_zlabel('y')
        ax.set_title('Fitness Landscape')

        # 显示图像
        plt.show()

    def __border_check(self, x):
        for i in range(self.__population_size):
            for j in range(self.__n_dim):
                if x[i, j] > self.__ub[j]:
                    x[i, j] = self.__ub[j]
                elif x[i, j] < self.__lb[j]:
                    x[i, j] = self.__lb[j]
        return x

    def optimize(self):
        print("Advanced Dung Beetle Optimizer starts to work! ")
        x = self.__initialize_population()
        # print(self.__calculate_dispersion_degree(x))
        # print(x)
        # exit()
        fitness_array = self.__calculate_fitness(x)
        fitness_array, index = self.__sort_fitness(fitness_array=fitness_array)
        x = self.__regenerate_sorted_x_array(x_old=x, index_old=index)
        last_dispersion_degree = self.__calculate_dispersion_degree(x=x)
        x_last_epoch = x  # x(t-1)
        global_best_score = fitness_array[0]
        global_best_position = np.zeros((1, self.__n_dim))
        global_best_position[0, :] = x[0, :]

        global_worst_score = fitness_array[-1]
        global_worst_position = np.zeros((1, self.__n_dim))
        global_worst_position[0, :] = x[-1, :]

        for epoch in range(self.__max_iteration):
            """
                使用屎壳郎优化策略
            """
            # # 滚球和舞蹈行为 Contribution2: 贪心滚球算法
            # x = self.__greedy_roll_ball_update(x=x, x_last_epoch=x_last_epoch,
            #                                    global_worst_position=global_worst_position, greedy_time=2)

            x = self.__roll_ball_update(x=x, x_last_epoch=x_last_epoch, global_worst_position=global_worst_position)
            fitness_array = self.__calculate_fitness(x)

            # 繁殖行为
            x = self.__brood_ball_update(x, epoch=epoch, fitness_array=fitness_array)
            # # 贪心繁殖行为 (不行)
            # x = self.__greedy_brood_ball_update(x,epoch=epoch,greedy_time=3)

            # 觅食行为
            x = self.__forage_update(x, epoch=epoch, fitness_array=fitness_array,
                                     global_best_position=global_best_position)
            fitness_array = self.__calculate_fitness(x)
            # 偷窃行为
            x = self.__thieve_update(x, epoch=epoch, global_best_position=global_best_position,
                                     fitness_array=fitness_array)
            fitness_array = self.__calculate_fitness(x)
            fitness_array, index = self.__sort_fitness(fitness_array=fitness_array)
            x = self.__regenerate_sorted_x_array(x_old=x, index_old=index)

            # 捕食屎壳郎
            dispersion_degree = self.__calculate_dispersion_degree(x)
            self.__modify_predator_coefficient(last_dispersion_degree=last_dispersion_degree,
                                               new_dispersion_degree=dispersion_degree)
            x = self.__predation_update(x_old=x)

            # 边界检查
            x = self.__border_check(x)
            fitness_array = self.__calculate_fitness(x)
            fitness_array, index = self.__sort_fitness(fitness_array=fitness_array)

            x = self.__regenerate_sorted_x_array(x_old=x, index_old=index)
            x_last_epoch = x
            last_dispersion_degree = self.__calculate_dispersion_degree(x)
            # 更新全局最优解
            if global_best_score >= fitness_array[0]:
                global_best_score = fitness_array[0]
                global_best_position[0, :] = x[0, :]
            self.__best_score_curve[epoch, 0] = copy.copy(global_best_score)
            self.__best_score_position[epoch, :] = copy.copy(global_best_position[0, :])
            if config.SHOW_EPOCH_BEST_RESULT and epoch % config.REMAINDER == 0:
                print("第%d代的最优搜索结果为:%.2f,位置:%s,捕食者系数:%.3f" % (epoch,
                                                              global_best_score,
                                                              global_best_position,
                                                              self.__predation_coe))
        # print("global_best_score:{},global_best_position:{},x:{},fitness:{}".format(global_best_score,
        # global_best_position,x,fitness_array))
        return global_best_score, global_best_position


if __name__ == '__main__':
    parameter_dict = {
        "mu": 1.02,
        "levy_rate": 0.2,
        "beta": 1.5,
        "predation_coe": 0.1
    }
    dim = 30
    low_boundary = -100 * np.ones((dim, 1))
    up_boundary = 100 * np.ones((dim, 1))
    # print("low boundary:{}, up boundary:{}".format(low_boundary, up_boundary))
    dbo_advanced = AdvancedDungBeetleOptimizer(func=step_f,
                                               n_dim=dim,
                                               population_size=100,
                                               max_iteration=1000,
                                               lb=low_boundary,
                                               ub=up_boundary,
                                               role_amount_distribution=[0.2, 0.2, 0.2, 0.4],
                                               param_dict=parameter_dict)

    best_score, best_position = dbo_advanced.optimize()
    dbo_advanced.draw_optimization_curve(is_save=True)
    pos, curve = dbo_advanced.export_optimization_procedure()
    util.export_data(file_path=os.path.join(config.RESULT_SAVING_PATH, "advanced_dbo_res.csv"),
                     data=curve.flatten().tolist())
    print("Advanced DBO 在{}处取得全局最优解:{}".format(best_position, best_score))
    # dbo_advanced.paint_x_position_and_function(lb=-100, ub=100, step=1)
