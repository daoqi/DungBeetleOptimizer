"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:dung_beetle_opt.py
@Created Time: 2023.04.15
"""

import copy
import math
import os
import time
import matplotlib.pyplot as plt
import numpy as np

from globals import DungBeetleRoleEnum
from globals import check_amount_distribution
from configuration import set_global_randomness
from configuration import config
from test_function import *
from globals import util
plt.rc('font', family='Times New Roman')
set_global_randomness()


class DungBeetleOptimizer:

    def __init__(self, func: callable,
                 n_dim: int,
                 population_size: int,
                 max_iteration: int,
                 lb: np.ndarray,
                 ub: np.ndarray,
                 role_amount_distribution: list):
        """
        :param func: 优化目标(适应度函数)
        :param n_dim: 优化参数个数
        :param population_size: 种群规模
        :param max_iteration: 最大迭代次数
        :param lb: 迭代范围下界
        :param ub: 迭代范围上界
        :param role_amount_distribution: 在蜣螂种群中四种角色的数量分布,加和为1
        """
        self.__func = func
        self.__n_dim = n_dim
        self.__population_size = population_size
        self.__max_iteration = max_iteration
        self.__lb = lb
        self.__ub = ub
        self.__role_ub = [0, 0, 0, 0]
        self.__best_score_curve = np.zeros((self.__max_iteration, 1))
        self.__best_score_position = np.zeros((self.__max_iteration, self.__n_dim))
        if check_amount_distribution(role_amount_distribution):
            self.__amount_distribution = role_amount_distribution
            self.__gen_role_range()
            # print("四种角色的蜣螂下标范围: ", self.__role_ub)
        else:
            raise ValueError("蜣螂种群的角色分布不满足定义,错误分布:{}".format(role_amount_distribution))

    def export_optimization_procedure(self):
        """
            导出优化过程中的最优解和其函数值,(最优解,最优函数值)
        :return:
        """
        return self.__best_score_position, self.__best_score_curve

    def draw_optimization_curve(self, is_save=True, file_str=""):
        x = [i for i in range(0, self.__best_score_curve.shape[0])]
        y = self.__best_score_curve[:, 0]
        plt.title("Optimization Curve")
        plt.plot(x, y)
        if self.__best_score_curve.all() > 0.0:
            plt.yscale("log")
        plt.xlabel("Epoch")
        plt.ylabel("Current epoch best score")
        if not is_save:
            plt.show()
        else:
            if len(file_str) == 0:
                file_str = time.strftime("%Y-%m-%d %H-%M-%S", time.localtime(time.time()))
            plt.savefig(os.path.join(config.IMAGE_SAVING_PATH, "DungBeetleOpt" + file_str))

    def __gen_role_range(self):
        """
            根据数量分布分别依次生成滚球蜣螂，产卵蜣螂,觅食蜣螂,偷窃蜣螂这四种角色的下标范围
        """
        last_num = 0
        for index in range(0, len(self.__amount_distribution)):
            last_num = last_num + round(self.__population_size * self.__amount_distribution[index])
            self.__role_ub[index] = last_num

    def __initialize_population(self):
        x = np.zeros([self.__population_size, self.__n_dim])
        for i in range(self.__population_size):
            for j in range(self.__n_dim):
                x[i, j] = np.random.rand() * (self.__ub[j] - self.__lb[j]) + self.__lb[j]
        return x

    def __roll_ball_update(self, x, x_last_epoch, global_worst_position):
        """
            滚球与跳舞行为
        """
        x_new = copy.copy(x)
        eta = np.random.rand(1)
        col_num = x.shape[1]
        b = 0.3
        for i in range(0, self.__role_ub[DungBeetleRoleEnum.ROLL_BALL_DUNG_BEETLE.value]):
            if eta < 0.9:
                alpha = np.random.rand(1)
                if alpha > 0.1:
                    a = 1
                else:
                    a = -1
                x_new[i, :] = x[i, :] + b * np.abs(x[i, :] - global_worst_position[0, :]) + a * 0.1 * (
                    x_last_epoch[i, :])  # Equation(1)
            else:
                # dance
                theta = np.random.randint(180, size=1)
                if theta == 0 or theta == 90 or theta == 180:
                    for j in range(0, col_num):
                        x_new[i, j] = x[i, j]
                temp_theta = theta * np.pi / 180
                x_new[i, :] = x[i, :] + math.tan(temp_theta) * np.abs(x[i, :] - x_last_epoch[i, :])  # Equation(2)
        # # 防止产生蜣螂位置超出解的约束空间
        # for i in range(self.__role_ub[DungBeetleRoleEnum.ROLL_BALL_DUNG_BEETLE.value]):
        #     for j in range(self.__n_dim):
        #         x_new[i, j] = np.clip(x_new[i, j], self.__lb[j], self.__ub[j])
        return x_new

    def __brood_ball_update(self, x, epoch, fitness_array):
        """
            产卵(繁殖)行为
        """
        x_new = copy.copy(x)
        r = 1 - epoch / self.__max_iteration
        # 找到x最小适应度的索引
        best_index = np.argmin(fitness_array)
        # 找到最优的蜣螂位置
        best_x = x[best_index, :]
        lb_star = best_x * (1 - r)
        ub_star = best_x * (1 + r)
        for row_i in range(0, self.__n_dim):
            # Equation(3)
            lb_star[row_i] = max(lb_star[row_i], self.__lb[row_i])
            ub_star[row_i] = max(ub_star[row_i], self.__ub[row_i])
        for i in range(self.__role_ub[DungBeetleRoleEnum.ROLL_BALL_DUNG_BEETLE.value] + 1,
                       self.__role_ub[DungBeetleRoleEnum.BROOD_BALL_DUNG_BEETLE.value]):
            # Equation(4)
            x_new[i, :] = best_x + (np.random.rand(1, self.__n_dim)) * (
                    x[i, :] - lb_star + (np.random.rand(1, self.__n_dim)) * (x[i, :] - ub_star))
            for j in range(self.__n_dim):
                x_new[i, j] = np.clip(x_new[i, j], lb_star[j], ub_star[j])
        return x_new

    def __forage_update(self, x, epoch, fitness_array, global_best_position):
        """
            小屎壳郎觅食更新
        """
        x_new = copy.copy(x)
        col_num = x.shape[1]
        r = 1 - epoch / self.__max_iteration
        lbb = global_best_position[0, :] * (1 - r)
        ubb = global_best_position[0, :] * (1 + r)
        for j in range(col_num):
            lbb[j] = np.clip(lbb[j], self.__lb[j], self.__ub[j])  # Equation(5)
            ubb[j] = np.clip(ubb[j], self.__lb[j], self.__ub[j])  # Equation(5)
        for i in range(self.__role_ub[DungBeetleRoleEnum.BROOD_BALL_DUNG_BEETLE.value] + 1,
                       self.__role_ub[DungBeetleRoleEnum.FORAGE_BALL_DUNG_BEETLE.value]):  # Equation(6)
            x_new[i, :] = x[i, :] + (np.random.rand(1, self.__n_dim)) * \
                          (x[i, :] - lbb) + (np.random.rand(1, self.__n_dim)) * \
                          (x[i, :] - ubb)
            for j in range(self.__n_dim):
                x_new[i, j] = np.clip(x_new[i, j], lbb[j], ubb[j])
        return x_new

    def __thieve_update(self, x, epoch, global_best_position, fitness_array):
        """
            偷窃更新
        """
        x_new = copy.copy(x)
        col_num = x.shape[1]
        f_min = np.min(fitness_array)  # 找到x中最小的适应度
        best_index = np.argmin(fitness_array)  # 找到x中最小适应度的索引
        best_x = x[best_index, :]  # 找到x中具有最有适应度的蜣螂位置
        for i in range(self.__role_ub[DungBeetleRoleEnum.FORAGE_BALL_DUNG_BEETLE.value] + 1,
                       self.__population_size):  # Equation(7)
            x_new[i, :] = global_best_position[0, :] + np.random.randn(1, self.__n_dim) * (
                    np.abs(x[i, :] - global_best_position[0, :]) + np.abs(x[i, :] - best_x)) / 2
            for j in range(self.__n_dim):
                x_new[i, j] = np.clip(x_new[i, j], self.__lb[j], self.__ub[j])
        return x_new

    def __calculate_fitness(self, x: np.ndarray) -> np.ndarray:
        row_num = x.shape[0]
        fitness = np.zeros([row_num, 1])
        for i in range(0, row_num):
            fitness[i] = self.__func(x[i, :].reshape(1, self.__n_dim))
            # print("计算:{},适应度:{}".format(x[i, :],fitness[i]))
        return fitness

    def __sort_fitness(self, fitness_array) -> tuple:
        sorted_fitness = np.sort(fitness_array, axis=0)
        index = np.argsort(fitness_array, axis=0)
        return sorted_fitness, index

    def __regenerate_sorted_x_array(self, x_old: np.ndarray, index_old: np.ndarray) -> np.ndarray:
        """
            适应度函数越小的解，在新的解集中的位置越靠近第0行
        """
        row_num = x_old.shape[0]
        x_new = np.zeros(x_old.shape)
        for i in range(0, row_num):
            x_new[i, :] = x_old[index_old[i], :]
        return x_new

    def __border_check(self, x):
        for i in range(self.__population_size):
            for j in range(self.__n_dim):
                if x[i, j] > self.__ub[j]:
                    x[i, j] = self.__ub[j]
                elif x[i, j] < self.__lb[j]:
                    x[i, j] = self.__lb[j]
        return x

    def optimize(self):
        print("Dung Beetle Optimizer starts to work! ")
        x = self.__initialize_population()
        # variances = np.var(x, axis=0)
        # total_variance = np.sum(variances)
        # print(total_variance)
        # print(x)
        # exit()
        fitness_array = self.__calculate_fitness(x)
        fitness_array, index = self.__sort_fitness(fitness_array=fitness_array)
        x = self.__regenerate_sorted_x_array(x_old=x, index_old=index)
        x_last_epoch = x  # x(t-only_chaotic_mapping)
        global_best_score = fitness_array[0]
        global_best_position = np.zeros((1, self.__n_dim))
        global_best_position[0, :] = x[0, :]

        global_worst_score = fitness_array[-1]
        global_worst_position = np.zeros((1, self.__n_dim))
        global_worst_position[0, :] = x[-1, :]

        for epoch in range(self.__max_iteration):
            # 滚球和舞蹈行为
            x = self.__roll_ball_update(x=x, x_last_epoch=x_last_epoch, global_worst_position=global_worst_position)
            fitness_array = self.__calculate_fitness(x)
            # 繁殖行为
            x = self.__brood_ball_update(x, epoch=epoch, fitness_array=fitness_array)
            # 觅食行为
            x = self.__forage_update(x, epoch=epoch, fitness_array=fitness_array,
                                     global_best_position=global_best_position)
            fitness_array = self.__calculate_fitness(x)
            # 偷窃行为
            x = self.__thieve_update(x, epoch=epoch, global_best_position=global_best_position,
                                     fitness_array=fitness_array)
            # 边界检查
            x = self.__border_check(x)
            fitness_array = self.__calculate_fitness(x)
            fitness_array, index = self.__sort_fitness(fitness_array=fitness_array)
            x = self.__regenerate_sorted_x_array(x_old=x, index_old=index)
            x_last_epoch = x
            # 更新全局最优解
            if global_best_score >= fitness_array[0]:
                global_best_score = fitness_array[0]
                global_best_position[0, :] = x[0, :]
            self.__best_score_curve[epoch, 0] = copy.copy(global_best_score)
            self.__best_score_position[epoch, :] = copy.copy(global_best_position[0, :])
            if config.SHOW_EPOCH_BEST_RESULT and epoch % config.REMAINDER == 0:
                print("第%d代的最优搜索结果为:%.2f,位置:%s" % (epoch, global_best_score, global_best_position))
        # print("global_best_score:{},global_best_position:{},x:{},fitness:{}".format(global_best_score, global_best_position,x,fitness_array))
        return global_best_score, global_best_position


if __name__ == '__main__':
    dim = 30
    low_boundary = -100 * np.ones((dim, 1))
    up_boundary = 100 * np.ones((dim, 1))
    # print("low boundary:{}, up boundary:{}".format(low_boundary, up_boundary))
    dbo = DungBeetleOptimizer(func=step_f,
                              n_dim=dim,
                              population_size=100,
                              max_iteration=1000,
                              lb=low_boundary,
                              ub=up_boundary,
                              role_amount_distribution=[0.2, 0.2, 0.2, 0.4])

    best_score, best_position = dbo.optimize()
    dbo.draw_optimization_curve(is_save=True)
    pos,curve = dbo.export_optimization_procedure()
    util.export_data(file_path=os.path.join(config.RESULT_SAVING_PATH,"dbo_res.csv"),
                     data = curve.flatten().tolist())
    print("DBO 在{}处取得全局最优解:{}".format(best_position, best_score))
