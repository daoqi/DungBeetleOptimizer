"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:advanced_dbo_without_predator.py
@Created Time: 2023.04.20
"""
"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:dung_beetle_opt.py
@Created Time: 2023.04.15
"""
import copy
import math
import os
import time
import matplotlib.pyplot as plt
import numpy as np
from numba import jit
from globals import DungBeetleRoleEnum
from globals import check_amount_distribution
from configuration import set_global_randomness, config
from globals.chaotic_mapping import SingerMapping, LogisticMapping
from test_function import schaffer, shubert, shubert_show, cigar

plt.rc('font', family='Times New Roman')
set_global_randomness()


class AdvancedDungBeetleOptimizer:
    """
        Contribution only_chaotic_mapping: 在初始化时,引入混沌映射,让初始种群分布更加分散
        Contribution 2: 在进入下一轮迭代前,针对部分适应度差的解应用Levy flight策略
    """

    def __init__(self, func: callable,
                 n_dim: int,
                 population_size: int,
                 max_iteration: int,
                 lb: np.ndarray,
                 ub: np.ndarray,
                 role_amount_distribution: list,
                 param_dict: dict = None):
        """
        :param func: 优化目标(适应度函数)
        :param n_dim: 优化参数个数
        :param population_size: 种群规模
        :param max_iteration: 最大迭代次数
        :param lb: 迭代范围下界
        :param ub: 迭代范围上界
        :param role_amount_distribution: 在蜣螂种群中四种角色的数量分布,加和为1
        :param param_dict: 其他优化参数
        """
        self.__func = func
        self.__n_dim = n_dim
        self.__population_size = population_size
        self.__max_iteration = max_iteration
        self.__lb = lb
        self.__ub = ub
        self.__role_ub = [0, 0, 0, 0]
        self.__best_score_curve = np.zeros((self.__max_iteration, 1))
        self.__best_score_position = np.zeros((self.__max_iteration, self.__n_dim))
        self.__param_dict = param_dict
        if check_amount_distribution(role_amount_distribution):
            self.__amount_distribution = role_amount_distribution
            self.__gen_role_range()
            # print("四种角色的蜣螂下标范围: ", self.__role_ub)
        else:
            raise ValueError("蜣螂种群的角色分布不满足定义,错误分布:{}".format(role_amount_distribution))

    def export_optimization_procedure(self):
        """
            导出优化过程中的最优解和其函数值
        :return:
        """
        return self.__best_score_position, self.__best_score_curve

    def draw_optimization_curve(self, is_save=True, file_str=""):
        x = [i for i in range(0, self.__best_score_curve.shape[0])]
        y = self.__best_score_curve[:, 0]
        plt.title("Optimization Curve(advanced)")
        plt.plot(x, y)
        plt.xlabel("Epoch")
        plt.ylabel("Current epoch best score")
        if not is_save:
            plt.show()
        else:
            if len(file_str) == 0:
                file_str = time.strftime("%Y-%m-%d %H-%M-%S", time.localtime(time.time()))
            plt.savefig(os.path.join(config.IMAGE_SAVING_PATH, "AdvancedDungBeetleOpt" + file_str))

    def __gen_role_range(self):
        """
            根据数量分布分别依次生成滚球蜣螂，产卵蜣螂,觅食蜣螂,偷窃蜣螂这四种角色的下标范围
        """
        last_num = 0
        for index in range(0, len(self.__amount_distribution)):
            last_num = last_num + round(self.__population_size * self.__amount_distribution[index])
            self.__role_ub[index] = last_num

    def __initialize_population(self):
        """
            Contribution only_chaotic_mapping: chaotic mapping,
            disperse the distribution of the initial population to prevent falling into a local optimal solution
        :return:
        """

        x = np.zeros([self.__population_size, self.__n_dim])
        for i in range(self.__population_size):
            for j in range(self.__n_dim):
                x[i, j] = np.random.rand() * (self.__ub[j] - self.__lb[j]) + self.__lb[j]
        temp_x = x
        singer_mapping = SingerMapping(x=x, mu=self.__param_dict["mu"])
        x = singer_mapping.generate_mapping_result()
        # TODO:还原那些超出搜索范围的解
        for i in range(0, self.__population_size):
            for j in range(self.__n_dim):
                if not self.__lb[j] <= x[i, j] <= self.__ub[j]:
                    x[i, j] = temp_x[i, j]
        return x

    def __roll_ball_update(self, x, x_last_epoch, global_worst_position):
        """
            滚球与跳舞行为
        """
        x_new = copy.copy(x)
        eta = np.random.rand(1)
        col_num = x.shape[1]
        b = 0.3
        for i in range(0, self.__role_ub[DungBeetleRoleEnum.ROLL_BALL_DUNG_BEETLE.value]):
            if eta < 0.9:
                alpha = np.random.rand(1)
                if alpha > 0.1:
                    alpha = 1
                else:
                    alpha = -1
                x_new[i, :] = x[i, :] + b * np.abs(x[i, :] - global_worst_position[0, :]) + alpha * 0.1 * (
                    x_last_epoch[i, :])  # Equation(only_chaotic_mapping)
            else:
                # dance
                theta = np.random.randint(180, size=1)
                if theta == 0 or theta == 90 or theta == 180:
                    for j in range(0, col_num):
                        x_new[i, j] = x[i, j]
                temp_theta = theta * np.pi / 180
                x_new[i, :] = x[i, :] + math.tan(temp_theta) * np.abs(x[i, :] - x_last_epoch[i, :])  # Equation(2)
        # 防止产生蜣螂位置超出解的约束空间
        for i in range(self.__role_ub[DungBeetleRoleEnum.ROLL_BALL_DUNG_BEETLE.value]):
            for j in range(self.__n_dim):
                x_new[i, j] = np.clip(x_new[i, j], self.__lb[j], self.__ub[j])
        return x_new

    def __brood_ball_update(self, x, epoch, fitness_array):
        """
            产卵(繁殖)行为
        """
        x_new = copy.copy(x)
        col_num = x.shape[1]
        r = 1 - epoch / self.__max_iteration
        # 找到x最小适应度的索引
        best_index = np.argmin(fitness_array)
        # 找到最优的蜣螂位置
        best_x = x[best_index, :]
        lb_star = best_x * (1 - r)
        ub_star = best_x * (1 + r)
        for j in range(0, col_num):
            # Equation(3)
            lb_star[j] = np.clip(lb_star[j], self.__lb[j], self.__ub[j])
            ub_star[j] = np.clip(ub_star[j], self.__lb[j], self.__ub[j])
        for i in range(self.__role_ub[DungBeetleRoleEnum.ROLL_BALL_DUNG_BEETLE.value] + 1,
                       self.__role_ub[DungBeetleRoleEnum.BROOD_BALL_DUNG_BEETLE.value]):
            # Equation(4)
            x_new[i, :] = best_x + (np.random.rand(1, col_num)) * (
                    x[i, :] - lb_star + (np.random.rand(1, col_num)) * (x[i, :] - ub_star))
            for j in range(self.__n_dim):
                x_new[i, j] = np.clip(x_new[i, j], lb_star[j], ub_star[j])
        return x_new

    def __forage_update(self, x, epoch, fitness_array, global_best_position):
        """
            小屎壳郎觅食更新
        """
        x_new = copy.copy(x)
        col_num = x.shape[1]
        r = 1 - epoch / self.__max_iteration
        lbb = global_best_position[0, :] * (1 - r)
        ubb = global_best_position[0, :] * (1 + r)
        for j in range(col_num):
            lbb[j] = np.clip(lbb[j], self.__lb[j], self.__ub[j])  # Equation(5)
            ubb[j] = np.clip(ubb[j], self.__lb[j], self.__ub[j])  # Equation(5)
        for i in range(self.__role_ub[DungBeetleRoleEnum.BROOD_BALL_DUNG_BEETLE.value] + 1,
                       self.__role_ub[DungBeetleRoleEnum.FORAGE_BALL_DUNG_BEETLE.value]):  # Equation(6)
            x_new[i, :] = x[i, :] + (np.random.rand(1, self.__n_dim)) * \
                          (x[i, :] - lbb) + (np.random.rand(1, self.__n_dim)) * \
                          (x[i, :] - ubb)
            for j in range(self.__n_dim):
                x_new[i, j] = np.clip(x_new[i, j], lbb[j], ubb[j])
        return x_new

    def __thieve_update(self, x, epoch, global_best_position, fitness_array):
        """
            偷窃更新
        """
        x_new = copy.copy(x)
        col_num = x.shape[1]
        f_min = np.min(fitness_array)  # 找到x中最小的适应度
        bestIndex = np.argmin(fitness_array)  # 找到x中最小适应度的索引
        best_x = x[bestIndex, :]  # 找到x中具有最有适应度的蜣螂位置
        for i in range(self.__role_ub[DungBeetleRoleEnum.FORAGE_BALL_DUNG_BEETLE.value] + 1,
                       self.__population_size):  # Equation(7)
            x_new[i, :] = global_best_position[0, :] + np.random.randn(1, self.__n_dim) * (
                    np.abs(x[i, :] - global_best_position[0, :]) + np.abs(x[i, :] - best_x)) / 2
            for j in range(self.__n_dim):
                x_new[i, j] = np.clip(x_new[i, j], self.__lb[j], self.__ub[j])
        return x_new

    def __levy_flight(self, last_x, beta=1.5):
        """
            添加levy飞行策略
        :param last_x:
        :param beta:
        :return:
        """
        res_x = np.zeros(shape=(last_x.shape[0], last_x.shape[1]))
        alpha_u = math.pow((np.math.gamma(1 + beta) * math.sin(math.pi * beta / 2) /
                            (np.math.gamma(((1 + beta) / 2) * beta * math.pow(2, (beta - 1) / 2)))),
                           (1 / beta))
        alpha_v = 1
        for i in range(0, last_x.shape[0]):
            for j in range(0, self.__n_dim):
                u = np.random.normal(0, alpha_u, 1)
                v = np.random.normal(0, alpha_v, 1)
                step = u / math.pow(abs(v), (1 / beta))
                res_x[i, j] = last_x[i, j] + step
        return res_x

    def __calculate_fitness(self, x: np.ndarray) -> np.ndarray:
        row_num = x.shape[0]
        fitness = np.zeros([row_num, 1])
        for i in range(0, row_num):
            fitness[i] = self.__func(x[i, :].reshape(1, self.__n_dim))
            # print("计算:{},适应度:{}".format(x[i, :],fitness[i]))
        return fitness

    def __sort_fitness(self, fitness_array) -> tuple:
        sorted_fitness = np.sort(fitness_array, axis=0)
        index = np.argsort(fitness_array, axis=0)
        return sorted_fitness, index

    def __regenerate_sorted_x_array(self, x_old: np.ndarray, index_old: np.ndarray) -> np.ndarray:
        """
            适应度函数越小的解，在新的解集中的位置越靠近第0行
        """
        row_num = x_old.shape[0]
        x_new = np.zeros(x_old.shape)
        for i in range(0, row_num):
            x_new[i, :] = x_old[index_old[i], :]
        return x_new

    def __roll_ball_greedy_search(self, x, x_last_epoch, global_worst_position):
        """

        :param x:
        :param x_last_epoch:
        :param global_worst_position:
        :return:
        """
        second_x = self.__roll_ball_update(x=x, x_last_epoch=x_last_epoch, global_worst_position=global_worst_position)
        fitness_array = self.__calculate_fitness(second_x)
        sorted_fitness, index = self.__sort_fitness(fitness_array=fitness_array)
        second_sorted_x = self.__regenerate_sorted_x_array(x_old=second_x, index_old=index)
        second_global_worst_position = np.zeros((1, self.__n_dim))
        second_global_worst_position[0, :] = second_x[-1, :]
        while sorted_fitness[0] < fitness_array[0]:
            # print("{} < {}".format(sorted_fitness[0],fitness_array[0]))
            second_x = self.__roll_ball_update(x=second_sorted_x, x_last_epoch=x_last_epoch,
                                               global_worst_position=second_global_worst_position)
            fitness_array = self.__calculate_fitness(second_x)
            sorted_fitness, index = self.__sort_fitness(fitness_array=fitness_array)
            second_sorted_x = self.__regenerate_sorted_x_array(x_old=second_x, index_old=index)
            second_global_worst_position[0, :] = second_x[-1, :]
        return second_x

    def paint_x_position_and_function(self, lb, ub, step=0.1):
        """
            对于绘制二元函数
            绘制每次迭代的点,在优化目标上的位置
        :return:
        """
        assert self.__n_dim == 2
        x_1 = np.arange(lb, ub, step)
        x_2 = np.arange(lb, ub, step)
        x_1, x_2 = np.meshgrid(x_1, x_2)
        x = np.c_[x_1.ravel(), x_2.ravel()]
        y = self.__calculate_fitness(x).reshape(x_1.shape)

        print(self.__best_score_curve.shape, self.__best_score_position.shape)
        point_x1 = self.__best_score_position[:, 0]
        point_x2 = self.__best_score_position[:, 1]
        point_y = self.__best_score_curve[:, 0]

        # 创建一个三维图形窗口
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')

        # 绘制三维图像
        ax.plot_surface(x_1, x_2, y, cmap='rainbow')
        # 绘制搜索结果
        ax.scatter(point_x1, point_x2, point_y, marker="*")
        # 添加标签和标题
        ax.set_xlabel('x_1')
        ax.set_ylabel('x_2')
        ax.set_zlabel('y')
        ax.set_title('Fitness Landscape')

        # 显示图像
        plt.show()

    def optimize(self):
        x = self.__initialize_population()
        fitness_array = self.__calculate_fitness(x)
        sorted_fitness, index = self.__sort_fitness(fitness_array=fitness_array)
        x = self.__regenerate_sorted_x_array(x_old=x, index_old=index)
        x_last_epoch = x  # x(t-only_chaotic_mapping)
        global_best_score = fitness_array[0]
        global_best_position = np.zeros((1, self.__n_dim))
        global_best_position[0, :] = x[0, :]

        global_worst_score = fitness_array[-1]
        global_worst_position = np.zeros((1, self.__n_dim))
        global_worst_position[0, :] = x[-1, :]

        for epoch in range(self.__max_iteration):
            # 滚球和舞蹈行为 Contribution2: 贪心滚球算法
            # x = self.__roll_ball_greedy_search(x=x, x_last_epoch=x_last_epoch,
            #                                    global_worst_position=global_worst_position)
            x = self.__roll_ball_update(x=x, x_last_epoch=x_last_epoch, global_worst_position=global_worst_position)
            fitness_array = self.__calculate_fitness(x)

            # 繁殖行为
            x = self.__brood_ball_update(x, epoch=epoch, fitness_array=fitness_array)
            # 觅食行为
            x = self.__forage_update(x, epoch=epoch, fitness_array=fitness_array,
                                     global_best_position=global_best_position)
            fitness_array = self.__calculate_fitness(x)
            # 偷窃行为
            x = self.__thieve_update(x, epoch=epoch, global_best_position=global_best_position,
                                     fitness_array=fitness_array)
            fitness_array = self.__calculate_fitness(x)
            sorted_fitness, index = self.__sort_fitness(fitness_array=fitness_array)
            x = self.__regenerate_sorted_x_array(x_old=x, index_old=index)
            # 对适应度差的后 k% 的个体添加levy飞行策略
            rate = self.__param_dict["levy_rate"]
            beta = self.__param_dict["beta"]
            index_levy = int(self.__population_size - self.__population_size * rate)
            x[index_levy:, :] = self.__levy_flight(last_x=x[index_levy:, :], beta=beta)
            fitness_array = self.__calculate_fitness(x)
            sorted_fitness, index = self.__sort_fitness(fitness_array=fitness_array)
            x_last_epoch = x
            # 更新全局最优解
            if global_best_score >= fitness_array[0]:
                global_best_score = fitness_array[0]
                global_best_position[0, :] = x[0, :]
            self.__best_score_curve[epoch] = global_best_score
            self.__best_score_position[epoch] = global_best_position[0, :]
            if config.SHOW_EPOCH_BEST_RESULT and epoch % config.REMAINDER == 0:
                print("第%d代的最优搜索结果为:%.2f,位置:%s" % (epoch, global_best_score, global_best_position))
        # print("global_best_score:{},global_best_position:{},x:{},fitness:{}".format(global_best_score,
        # global_best_position,x,fitness_array))
        return global_best_score, global_best_position


if __name__ == '__main__':
    parameter_dict = {
        "mu": 1.02,
        "levy_rate": 0.2,
        "beta": 1.5,
    }
    dim = 30
    low_boundary = -100 * np.ones((dim, 1))
    up_boundary = 100 * np.ones((dim, 1))
    # print("low boundary:{}, up boundary:{}".format(low_boundary, up_boundary))
    dbo_advanced = AdvancedDungBeetleOptimizer(func=cigar,
                                               n_dim=dim,
                                               population_size=100,
                                               max_iteration=1000,
                                               lb=low_boundary,
                                               ub=up_boundary,
                                               role_amount_distribution=[0.2, 0.2, 0.2, 0.4],
                                               param_dict=parameter_dict)

    best_score, best_position = dbo_advanced.optimize()
    dbo_advanced.draw_optimization_curve()
    print("Advanced DBO 在{}处取得全局最优解:{}".format(best_position, best_score))
    # dbo_advanced.paint_x_position_and_function(lb=-100, ub=100, step=1)
