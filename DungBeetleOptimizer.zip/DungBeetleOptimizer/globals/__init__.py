"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:__init__.py.py
@Created Time: 2023.04.16
"""
from .dung_beetle_role import DungBeetleRoleEnum
from .util import check_amount_distribution
