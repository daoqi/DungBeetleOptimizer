"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:util.py
@Created Time: 2023.04.16
"""
import time
import os
import matplotlib.pyplot as plt
import numpy as np
from configuration import config

plt.rc('font', family='Times New Roman')

_DUNG_BEETLE_AMOUNT = 4


def check_amount_distribution(ls: list):
    res = sum(ls)
    if _DUNG_BEETLE_AMOUNT == len(ls) and 1 == res:
        return True
    return False


def show_figure(avg_score_curve: np.ndarray, figure_title="", is_save=False, file_name=""):
    x = [i for i in range(0, avg_score_curve.shape[0])]
    y = avg_score_curve[:, 0]
    plt.title(figure_title)
    plt.plot(x, y)
    plt.xlabel("Epoch")
    plt.ylabel("Average best score")
    if not is_save:
        plt.show()
    else:
        if len(file_name) == 0:
            file_name = time.strftime("Unknown: %Y-%m-%d %H-%M-%S", time.localtime(time.time()))
        plt.savefig(os.path.join(config.IMAGE_SAVING_PATH, file_name))
    plt.close()


def show_figure_together(
        file_dir: str,
        avg_score_curve: np.ndarray,
        avg_score_curve_advanced: np.ndarray,
        is_save=False,
        figure_title: str = "Iteration count comparison",
        file_name=""):
    x = [i for i in range(0, avg_score_curve.shape[0])]
    y1 = avg_score_curve[:, 0]
    y2 = avg_score_curve_advanced[:, 0]
    plt.plot(x, y1, color="b", label="DBO")
    plt.plot(x, y2, color="r", label="Advanced DBO")
    plt.xlabel("Iteration")
    plt.ylabel("Average Best Score")
    plt.legend()
    plt.title(figure_title)
    if not is_save:
        plt.show()
    else:
        if len(file_name) == 0:
            file_name = time.strftime("Unknown: %Y-%m-%d %H-%M-%S", time.localtime(time.time()))
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        plt.savefig(os.path.join(file_dir, file_name))
    plt.close()


def save_experiment_result(file_name: str, content: str, file_dir: str = ""):
    if len(file_dir) == 0:
        with open(file=os.path.join(config.IMAGE_SAVING_PATH, file_name + ".txt"), mode="w", encoding="utf-8") as f:
            f.write(content)
    else:
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        else:
            with open(file=os.path.join(file_dir, file_name + ".txt"), mode="w", encoding="utf-8") as f:
                f.write(content)


def export_figure(figure_title: str,
                  line_name_list: list,
                  y_list: list,
                  is_log: bool,
                  is_save: bool,
                  file_dir: str,
                  file_name: str):
    if len(y_list) <= 0:
        return

    x = [i for i in range(len(y_list[0]))]
    y_index = 0

    for line_name in line_name_list:
        y = y_list[y_index]
        print("{} 画图数据: ".format(line_name), y)
        plt.plot(x, y, label=line_name)
        y_index += 1
    plt.xlabel("Iteration")
    plt.ylabel("Average objective function value")
    plt.legend()
    plt.title(figure_title)
    if not is_save:
        plt.show()
    else:
        if len(file_name) == 0:
            file_name = time.strftime("Unknown: %Y-%m-%d %H-%M-%S", time.localtime(time.time()))
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        plt.savefig(os.path.join(file_dir, file_name))
    plt.close()


def export_data(file_path: str, data):
    with open(file_path, "w", encoding="utf-8") as f:
        f.writelines("Iteration,Curve\n")
        for i in range(0, len(data)):
            lines = "{},{}\n".format(i + 1, data[i])
            f.writelines(lines)
