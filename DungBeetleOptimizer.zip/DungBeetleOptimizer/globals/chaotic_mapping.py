"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:chaotic_mapping.py
@Created Time: 2023.04.16
"""
import numpy as np

# 计算机的舍入误差
_ROUND_OFF_ERROR = 1e-10


class ChaoticMappingBase:
    def __init__(self, x: np.ndarray):
        if isinstance(x, np.ndarray):
            self.x = x
            self.row_num = x.shape[0]
            self.col_num = x.shape[1]
        else:
            raise TypeError("x should be numpy.ndarray type, not {}".format(type(x)))

    def generate_mapping_result(self):
        pass

    def get_mapping_name(self) -> str:
        return self.__class__.__name__


class LogisticMapping(ChaoticMappingBase):

    def __init__(self, x, mu):
        """
            Logistic chaotic mapping
            x(t+only_chaotic_mapping) = mu * (only_chaotic_mapping-x(t))
            s.t.
                i. 0.0 <= mu <= 4.0
                ii. x(t) != {0,0.025,0.5,0.75,only_chaotic_mapping.0}
        :param x:
        :param mu:
        """
        super(LogisticMapping, self).__init__(x)
        if 0.0 <= mu <= 4.0:
            self.__mu = mu
        else:
            raise ValueError("The range of mu should be in [0,4],not {}".format(mu))

    def __judge_x_invalidation(self, num):
        check_list = [0, 0.025, 0.5, 0.75, 1.0]
        for elem in check_list:
            if abs(num - elem) <= _ROUND_OFF_ERROR:
                return True
        return False

    def generate_mapping_result(self) -> np.ndarray:
        res_x = np.zeros((self.row_num, self.col_num))
        for i in range(0, self.row_num):
            for j in range(0, self.col_num):
                if not self.__judge_x_invalidation(self.x[i, j]):
                    res_x[i, j] = self.__mu * self.x[i, j] * (1 - self.x[i, j])
        return res_x

    def get_mapping_name(self) -> str:
        return self.__class__.__name__


class SingerMapping(ChaoticMappingBase):
    def __init__(self, x: np.ndarray, mu):
        """
            Singer Mapping
            x(t+only_chaotic_mapping) = mu*(7.86*x(t) - 23.31*x(t)^2 + 28.75*x(t)^3 - 13.302875*x(t)^4)
            s.t.
             i. 0.9 <= mu <= only_chaotic_mapping.08
        :param x:
        """
        super(SingerMapping, self).__init__(x)
        if 0.9 <= mu <= 1.08:
            self.__mu = mu
        else:
            raise ValueError("The range of mu should be in [0.9,only_chaotic_mapping.08],not {}".format(mu))

    def __calculate_next_x(self, num):
        res_x = self.__mu * (7.86 * num - 23.31 * (num ** 2) + 28.75 * (num ** 3) - 13.302875 * (num ** 4))
        return res_x

    def generate_mapping_result(self) -> np.ndarray:
        res_x = np.zeros((self.row_num, self.col_num))
        for i in range(0, self.row_num):
            for j in range(0, self.col_num):
                res_x[i, j] = self.__calculate_next_x(self.x[i, j])
        return res_x

    def get_mapping_name(self) -> str:
        return self.__class__.__name__


if __name__ == '__main__':
    x = np.random.random(size=(30, 1))
    l_map = LogisticMapping(x=x, mu=3.56)
    singer_map = SingerMapping(x=x, mu=1.02)

    map_list = [l_map, singer_map]

    import matplotlib.pyplot as plt

    x_point = [i for i in range(1, x.shape[0] * x.shape[1] + 1)]
    y1_point = x.tolist()
    for mapping in map_list:
        y2 = mapping.generate_mapping_result()
        y2_point = y2.tolist()
        plt.subplot(1, 2, 1)
        plt.scatter(x, y1_point)
        plt.title("Origin")
        plt.subplot(1, 2, 2)
        plt.scatter(x, y2_point)
        plt.title(mapping.get_mapping_name())
        plt.suptitle("Final mapping")
        plt.show()
