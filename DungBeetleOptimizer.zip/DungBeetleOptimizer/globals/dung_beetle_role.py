"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:dung_beetle_role.py
@Created Time: 2023.04.16
"""

from enum import Enum


class DungBeetleRoleEnum(Enum):
    ROLL_BALL_DUNG_BEETLE = 0
    BROOD_BALL_DUNG_BEETLE = 1
    FORAGE_BALL_DUNG_BEETLE = 2
    THIEVE_BALL_DUNG_BEETLE = 3
