"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:__init__.py.py
@Created Time: 2023.04.16
"""

from .config import set_global_randomness
