"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:config.py
@Created Time: 2023.04.16
"""
import os
import random
import numpy as np
from test_function import *

# 配置随机性(None->无随机性,其他->随机种子)
__RANDOMNESS = 10010
# 配置画图路径(DungBeetleOptimizer/img)
IMAGE_SAVING_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "img")
# 配置实验结果保存路径(DungBeetleOptimizer/result)
RESULT_SAVING_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "result")
# 配置是否在优化过程中打印最优搜索结果
SHOW_EPOCH_BEST_RESULT = True
# 每REMAINDER次打印一次输出
REMAINDER = 100
# 允许的误差
ROUNDING_ERROR = 1e-50
# CVRP 数据集目录
CVRP_DATA_SET = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "vrp_set_hg")
# 暂存路径
TEMP_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "temp")


def export_test_function() -> dict:
    """
        导出实验所用函数信息 {"":{}}
        函数参数包含:
            1.函数名
            2.函数本体
            3.优化目标个数
            4.下限
            5.上限
            6.全局最小值
    :return:
    """
    function_dict = {
        "F1": {
            "function_name": "sphere",
            "function": sphere,
            "dim": 30,
            "lb": -5.12,
            "ub": 5.12,
            "global_minima": 0,
            "func_type": "Unimodal test function"
        },
        "F2": {
            "function_name": "schwefel_2_22",
            "function": schwefel_2_22,
            "dim": 30,
            "lb": -10,
            "ub": 10,
            "global_minima": 0,
            "func_type": "Unimodal test function"
        },
        "F3": {
            "function_name": "rosenbrock",
            "function": rosenbrock,
            "dim": 30,
            "lb": -30,
            "ub": 30,
            "global_minima": 0,
            "func_type": "Unimodal test function"
        },
        "F4": {
            "function_name": "step_f",
            "function": step_f,
            "dim": 30,
            "lb": -100,
            "ub": 100,
            "global_minima": 0,
            "func_type": "Unimodal test function"
        },
        "F5": {
            "function_name": "quartic_function_noise",
            "function": quartic_function_noise,
            "dim": 30,
            "lb": -1.28,
            "ub": 1.28,
            "global_minima": 0,
            "func_type": "Unimodal test function"
        },
        "F6": {
            "function_name": "rotated_hyper_ellipsoid",
            "function": rotated_hyper_ellipsoid,
            "dim": 30,
            "lb": -65.536,
            "ub": 65.536,
            "global_minima": 0,
            "func_type": "Unimodal test function"
        },
        "F7": {
            "function_name": "sum_of_diff_power",
            "function": sum_of_diff_power,
            "dim": 30,
            "lb": -1,
            "ub": 1,
            "global_minima": 0,
            "func_type": "Unimodal test function"
        },
        "F8": {
            "function_name": "ackley",
            "function": ackley,
            "dim": 30,
            "lb": -32,
            "ub": 32,
            "global_minima": 0,
            "func_type": "Multimodal test function"
        },
        "F9": {
            "function_name": "griewank",
            "function": griewank,
            "dim": 30,
            "lb": -600,
            "ub": 600,
            "global_minima": 0,
            "func_type": "Multimodal test function"
        },
        "F10": {
            "function_name": "rastrigrin",
            "function": rastrigrin,
            "dim": 30,
            "lb": -5.12,
            "ub": 5.12,
            "global_minima": 0,
            "func_type": "Multimodal test function"
        },
        "F11": {
            "function_name": "schwefel",
            "function": schwefel,
            "dim": 30,
            "lb": -500,
            "ub": 500,
            "global_minima": 0,
            "func_type": "Multimodal test function"
        },
        "F12": {
            "function_name": "generalized_penalized_function",
            "function": generalized_penalized_function,
            "dim": 30,
            "lb": -50,
            "ub": 50,
            "global_minima": 0,
            "func_type": "Multimodal test function"
        },
        "F13": {
            "function_name": "shubert",
            "function": shubert,
            "dim": 2,
            "lb": -10,
            "ub": 10,
            "global_minima": -186.7309,
            "func_type": "Fixed-dimension test function"
        },
        "F14": {
            "function_name": "michalewicz",
            "function": michalewicz,
            "dim": 2,
            "lb": 0,
            "ub": np.pi,
            "global_minima": -1.8013,
            "func_type": "Fixed-dimension test function"
        },
        "F15": {
            "function_name": "six_hump_camel",
            "function": six_hump_camel,
            "dim": 2,
            "lb": -5,
            "ub": 5,
            "global_minima": -1.0316,
            "func_type": "Fixed-dimension test function"
        },
        "F16": {
            "function_name": "colville",
            "function": colville,
            "dim": 4,
            "lb": -10,
            "ub": 10,
            "global_minima": 0,
            "func_type": "Fixed-dimension test function"
        },
        "F17": {
            "function_name": "de_jong",
            "function": de_jong,
            "dim": 2,
            "lb": -65.536,
            "ub": 65.536,
            "global_minima": 0,
            "func_type": "Fixed-dimension test function"
        },
        "F18": {
            "function_name": "hartman_dim_3",
            "function": hartman_dim_3,
            "dim": 3,
            "lb": 0,
            "ub": 1,
            "global_minima": -3.86278,
            "func_type": "Fixed-dimension test function"
        },
        "F19": {
            "function_name": "hartman_dim_6",
            "function": hartman_dim_6,
            "dim": 6,
            "lb": 0,
            "ub": 1,
            "global_minima": -3.32237,
            "func_type": "Fixed-dimension test function"
        }
    }

    return function_dict


def set_global_randomness(specified_seed=__RANDOMNESS):
    if specified_seed is None:
        pass
    if isinstance(specified_seed, int):
        random.seed(specified_seed)
        np.random.seed(specified_seed)

