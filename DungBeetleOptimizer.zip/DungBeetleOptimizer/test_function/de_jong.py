"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:de_jong.py
@Created Time: 2023.04.23
"""
import numpy as np


def de_jong(x: np.ndarray):
    """
    https://www.sfu.ca/~ssurjano/dejong5.html
    x1,x2 in [-65.536, 65.536]
    :param x:
    :return:
    """
    assert 2 == x.shape[1]
    a = np.array(
        [[-32, -16, 0, 16, 32, -32, -16, 0, 16, 32, -32, -16, 0, 16, 32, -32, -16, 0, 16, 32, -32, -16, 0, 16, 32],
         [-32, -32, -32, -32, -32, -16, -16, -16, -16, -16, 0, 0, 0, 0, 0, 16, 16, 16, 16, 16, 32, 32, 32, 32, 32]])

    res = 0
    for ii in range(0, 25):
        a1i = a[0, ii]
        a2i = a[1, ii]
        term1 = ii + 1
        term2 = (x[0, 0] - a1i) ** 6
        term3 = (x[0, 1] - a2i) ** 6
        res += (1 / (term1 + term2 + term3))

    y = 1 / (0.002 + res)
    return y


if __name__ == '__main__':
    print(de_jong(np.zeros((1, 2))))
