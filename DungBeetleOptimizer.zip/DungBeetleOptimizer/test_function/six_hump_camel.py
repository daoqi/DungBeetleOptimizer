"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:six_hump_camel.py
@Created Time: 2023.04.23
"""
import numpy as np


def six_hump_camel(x:np.ndarray):
    """
    https://www.sfu.ca/~ssurjano/camel6.html
    :param x:
    :return:
    """
    assert 2 == x.shape[1]
    x_1 = x[0,0]
    x_2 = x[0,1]
    term1 = (4-(2.1*(x_1**2))+((x_1**4)/3))*x_1**2
    term2 = x_1*x_2
    term3 = (-4+4*x_2**2)*x_2**2
    res = term1+term2+term3
    return res

if __name__ == '__main__':
    _x = np.array([0.0898,-0.7126]).reshape((1,2))
    print(six_hump_camel(_x))