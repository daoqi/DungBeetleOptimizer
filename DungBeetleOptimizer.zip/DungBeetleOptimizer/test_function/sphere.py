"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:sphere.py
@Created Time: 2023.04.17
"""
import numpy as np

from numba import jit


@jit(nopython=True)
def sphere(p):
    """
     Sphere函数,sum(x_i^2)
    :param p:(1,n)
    :return:
    """
    res_val = np.sum(p**2)
    return res_val


def test_sphere(col_vec: np.ndarray):
    print("Shape:{},val:{}".format(col_vec.shape, sphere(col_vec)))


if __name__ == '__main__':
    x = np.zeros((1, 30))
    test_sphere(x)
