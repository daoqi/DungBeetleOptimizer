"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:rosenbrock.py
@Created Time: 2023.04.17
"""

import numpy as np


def rosenbrock(p):
    '''
    -2.048<=xi<=2.048
    函数全局最优点在一个平滑、狭长的抛物线山谷内，使算法很难辨别搜索方向，查找最优也变得十分困难
    在(0,..,0)处可以找到极小值0
    :param p:
    :return:
    '''
    res = 0
    for i in range(0, p.shape[1] - 1):
        res += 100 * \
               np.square(np.square(p[0,i]) - p[0,i + 1]) + np.square(p[0,i] - 1)
    return res


def test_rosenbrock(col_vec: np.ndarray):
    print("Shape:{},val:{}".format(col_vec.shape, rosenbrock(col_vec)))


if __name__ == '__main__':
    x = np.full((1, 30), fill_value=1)
    test_rosenbrock(col_vec=x)
