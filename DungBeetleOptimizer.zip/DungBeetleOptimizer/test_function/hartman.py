"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:goldstein_price.py
@Created Time: 2023.04.25
"""

import numpy as np


def hartman_dim_3(x:np.ndarray):
    """
    [0.114614,0.555649,0.852547] 处取最小值 -3.86278
    :param x:
    :return:
    """
    assert x.shape[1] == 3
    a = np.array([[3, 10, 30], [0.1, 10, 35], [3, 10, 30], [0.1, 10, 35]])
    c = np.array([1, 1.2, 3, 3.2])
    p = np.array([[0.3689, 0.117, 0.2673], [0.4699, 0.4387, 0.747],
                  [0.1091, 0.8732, 0.5547], [0.03815, 0.5743, 0.8828]])
    res = 0
    for i in range(0, 4):
        res = res - c[i] * np.exp(-(np.sum(a[i] * ((x - p[i]) ** 2))))
    return res


def hartman_dim_6(x):
    """
    [0.20169,0.150011,0.476874,0.275332,0.311652,0.6573]取最小值-3.32237
    :param x:
    :return:
    """
    assert x.shape[1] == 6
    a = np.array(
        [[10, 3, 17, 3.5, 1.7, 8], [0.05, 10, 17, 0.1, 8, 14], [3, 3.5, 1.7, 10, 17, 8], [17, 8, 0.05, 10, 0.1, 14]])
    c = np.array([1, 1.2, 3, 3.2])
    p = np.array([[0.1312, 0.1696, 0.5569, 0.0124, 0.8283, 0.5886], [0.2329, 0.413, 0.8307, 0.3736, 0.1004, 0.9991],
                  [0.2348, 0.1415, 0.3522, 0.2883, 0.3047, 0.6650], [0.4047, 0.8828, 0.8732, 0.5743, 0.1091, 0.0381]])
    res = 0
    for i in range(0, 4):
        res = res - c[i] * np.exp(-(np.sum(a[i] * ((x - p[i]) ** 2))))
    return res

if __name__ == '__main__':
    _x1 = np.array([0.114614,0.555649,0.852547]).reshape((1,3))
    print(hartman_dim_3(_x1))
    _x2 = np.array([0.20169,0.150011,0.476874,0.275332,0.311652,0.6573]).reshape((1,6))
    print(hartman_dim_6(_x2))