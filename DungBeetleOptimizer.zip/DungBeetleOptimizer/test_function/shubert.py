"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:shubert.py
@Created Time: 2023.04.17
"""
import numpy as np
import matplotlib.pyplot as plt
from numba import jit


def shubert(p):
    """
    2-dimension
    -10<=x1,x2<=10
    has 760 local minima, 18 of which are global minima with -186.7309

    :param p:
    :return:
    """
    x_1 = p[0, 0]
    x_2 = p[0, 1]
    part1 = [i * np.cos((i + 1) * x_1 + i) for i in range(1, 6)]
    part2 = [i * np.cos((i + 1) * x_2 + i) for i in range(1, 6)]
    res = np.sum(part1) * np.sum(part2)
    return res


def shubert_show(x_1, x_2):
    part1 = [i * np.cos((i + 1) * x_1 + i) for i in range(1, 6)]
    part2 = [i * np.cos((i + 1) * x_2 + i) for i in range(1, 6)]
    return np.sum(part1) * np.sum(part2)


def test_shubert(col_vec: np.ndarray):
    print("Shape:{},val:{}".format(col_vec.shape, shubert(col_vec)))


if __name__ == '__main__':
    x = np.zeros((1, 2))
    test_shubert(col_vec=x)
