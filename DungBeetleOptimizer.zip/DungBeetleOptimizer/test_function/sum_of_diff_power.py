"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:sum_of_diff_power.py
@Created Time: 2023.04.23
"""
import numpy as np


def sum_of_diff_power(x: np.ndarray):
    res = 0
    for i in range(0, x.shape[1]):
        term = np.abs(x[0, i]) ** (i + 1)
        res += term
    return res


if __name__ == '__main__':
    print(sum_of_diff_power(np.zeros((1, 30))))
