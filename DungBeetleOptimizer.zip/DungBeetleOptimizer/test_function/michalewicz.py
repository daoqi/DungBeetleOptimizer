"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:michalewicz.py
@Created Time: 2023.04.23
"""
import numpy as np


def michalewicz(x: np.ndarray):
    """
    (2.20,1.57) 处取全局最小值-1.8013
    :param x:
    :return:
    """
    dim = x.shape[1]
    assert dim == 2
    m = 10
    res = 0
    for j in range(1, dim + 1):
        term_1 = np.sin(x[0, j - 1])
        term_2 = np.sin((j * x[0, j - 1] ** 2) / np.pi) ** (2 * m)
        res += (term_1 * term_2)
    return -res


if __name__ == '__main__':
    _x = np.array([2.20, 1.57]).reshape(1, 2)
    print(michalewicz(_x))
