"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:quartic_function_noise.py
@Created Time: 2023.04.23
"""

import numpy as np


def quartic_function_noise(x: np.ndarray):
    """
    The function has one global minimum f(x*)=0+random noise at x*=(0,…,0).
    :param x:
    :return:
    """
    i = np.arange(1, len(x) + 1)
    res = np.sum(i * (x ** 4)) + np.random.random()
    return res


if __name__ == '__main__':
    _x = np.zeros((1, 30))
    print(quartic_function_noise(_x))
