"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:rotated_hyper_ellipsoid.py
@Created Time: 2023.04.23
"""
import numpy as np


def rotated_hyper_ellipsoid(x: np.ndarray):
    """
    https://www.sfu.ca/~ssurjano/rothyp.html
    :param x:
    :return:
    """
    res = 0
    for i in range(len(x)):
        res = res + np.square(np.sum(x[0:i + 1]))
    return res


if __name__ == '__main__':
    _x = np.zeros((1, 30))
    print(rotated_hyper_ellipsoid(_x))
