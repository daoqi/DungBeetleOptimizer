"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:cigar.py
@Created Time: 2023.04.17
"""

import numpy as np
from test_function.sphere import sphere
from numba import jit


@jit(nopython=True)
def cigar(col_vec: np.ndarray):
    """
    多峰全局优化函数，域为-100<=xi<=100，对于 i=1...n。
    f(0,...0) 的全局最小值为 0
    :param col_vec: (1,n)
    :return:
    """
    res = np.square(col_vec[:, 0]) + np.power(10.0, 6) * sphere(col_vec[:, 1:])
    return res


def test_cigar(p: np.ndarray):
    print("Shape:{},function val:{}".format(p.shape, cigar(p)), )


if __name__ == '__main__':
    x = np.zeros((1, 30))
    test_cigar(x)
