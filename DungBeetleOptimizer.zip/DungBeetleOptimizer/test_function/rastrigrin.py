"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:rastrigrin.py
@Created Time: 2023.04.17
"""

import numpy as np


def rastrigrin(p):
    '''
    多峰值函数，也是典型的非线性多模态函数
    -5.12<=xi<=5.12 (i=1 ,...,n)
    在范围内有10n个局部最小值，峰形高低起伏不定跳跃。很难找到全局最优
    has a global minimum at x = 0  where f(x) = 0
    '''
    return np.sum([np.square(x) - 10 * np.cos(2 * np.pi * x) + 10 for x in p])

def test_rastrigrin(col_vec: np.ndarray):
    print("Shape:{},val:{}".format(col_vec.shape, rastrigrin(col_vec)))


if __name__ == '__main__':
    x = np.zeros((1, 30))
    test_rastrigrin(col_vec=x)