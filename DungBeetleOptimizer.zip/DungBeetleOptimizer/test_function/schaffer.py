"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:schaffer.py
@Created Time: 2023.04.15
"""
import numpy as np


def schaffer(p):
    """
        Schaffer function N. 2
        This function has plenty of local minimum, with strong shocks
        global minimum at (0,0) with value 0
        https://en.wikipedia.org/wiki/Test_functions_for_optimization
    :param p: np.ndarray (1,2)
    :return:
    """
    x1 = p[0, 0]
    x2 = p[0, 1]
    part1 = np.square(x1) - np.square(x2)
    part2 = np.square(x1) + np.square(x2)
    return 0.5 + (np.square(np.sin(part1)) - 0.5) / np.square(1 + 0.001 * part2)


def test_schaffer(col_vec: np.ndarray):
    print("Shape:{},val:{}".format(col_vec.shape, schaffer(col_vec)))


if __name__ == '__main__':
    x = np.zeros((1, 2))
    test_schaffer(col_vec=x)
