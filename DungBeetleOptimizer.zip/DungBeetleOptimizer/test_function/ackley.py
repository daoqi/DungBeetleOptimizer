"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:ackley.py
@Created Time: 2023.04.22
"""

import numpy as np


def ackley_n_2(p):
    """ Ackley_N.2
    -32<=xi<=32. Convex 2dim , non-seperable function .
    The global minimum value -200 can be found at f(0,0)
    :param p:
    :return:
    """
    x = p[:, 0]
    y = p[:, 1]
    return -200 * np.exp(-0.02 * np.sqrt(np.square(x)) + np.square(y))


def ackley(x: np.ndarray):
    """
    该函数具有多个局部最小值,-32.768<=xi<=32.768,i = 1,...,d
    在(0,...,0)取得全局最小值 0 (4.440892098500626e-16)
    :param x: (1,dim)
    :return:
    """
    a = 20
    b = 0.2
    c = 2 * np.pi
    d = x.shape[1]
    square_sum = 0.0
    cos_sum = 0.0
    for i in range(0, d):
        square_sum += x[0, i] ** 2
        cos_sum += np.cos(c * x[0, i])
    part1 = -a * np.exp(-b * np.sqrt(square_sum / d))
    part2 = -np.exp(np.sum(cos_sum / d))
    return part1 + part2 + a + np.exp(1)


if __name__ == '__main__':
    x = np.zeros((1, 30))
    print(ackley(x))
