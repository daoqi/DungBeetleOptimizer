"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:colville.py
@Created Time: 2023.04.23
"""
import numpy as np


def colville(x: np.ndarray):
    """
        (1,1,1,1) 取全局最小值 0.0
    :param x:
    :return:
    """
    assert 4 == x.shape[1]
    x_1 = x[0, 0]
    x_2 = x[0, 1]
    x_3 = x[0, 2]
    x_4 = x[0, 3]
    term_1 = 100 * ((x_1 ** 2 - x_2) ** 2)
    term_2 = (x_1 - 1) ** 2
    term_3 = (x_3 - 1) ** 2
    term_4 = 90 * ((x_3 ** 2 - x_4) ** 2)
    term_5 = 10.1 * ((x_2 - 1) ** 2 + (x_4 - 1) ** 2)
    term_6 = 19.8 * (x_2 - 1) * (x_4 - 1)
    return term_1 + term_2 + term_3 + term_4 + term_5 + term_6


if __name__ == '__main__':
    _x = np.ones((1, 4))
    print(colville(_x))
