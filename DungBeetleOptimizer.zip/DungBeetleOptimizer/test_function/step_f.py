"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:f3.py
@Created Time: 2023.04.23
"""
import numpy as np
import matplotlib.pyplot as plt

def step_f(x: np.ndarray):
    """
        单峰测试函数 [-100,100] 全局最小值0
    :param x:
    :return:
    """
    res = np.sum(np.square(np.abs(x[0, :] + 0.5)))

    return res



if __name__ == '__main__':
    _x = np.full((1, 30),fill_value=-0.5)
    print(step_f(_x))
