"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:schwefel.py
@Created Time: 2023.04.23
"""
import numpy as np

def schwefel_2_22(x:np.ndarray):
    """
        范围[-10,10] 全局最小值 0
    :param x:
    :return:
    """
    res = np.sum(np.abs(x)) + np.prod(np.abs(x))
    return res

def schwefel(x: np.ndarray):
    """
        多峰优化函数,在[420.9687,..,420.9687]取得全局最小值0
    :param x:
    :return:
    """
    d = x.shape[1]
    part1 = 418.9829 * d
    part2 = 0.0
    for i in range(0, d):
        part2 += x[0, i] * np.sin(np.sqrt(np.abs(x[0, i])))

    return part1-part2

if __name__ == '__main__':
    _x = np.full((1,30),fill_value=420.9687)
    print(schwefel(_x))