"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:griewank.py
@Created Time: 2023.04.17
"""
import numpy as np


def griewank(p):
    """
    https://www.sfu.ca/~ssurjano/griewank.html
    存在多个局部最小值点，数目与问题的维度有关。
    此函数是典型的非线性多模态函数，具有广泛的搜索空间，是优化算法很难处理的复杂多模态问题。
    在(0,...,0)处取的全局最小值0
    -600<=xi<=600
    :param p:
    :return:
    """
    part1 = [np.square(x) / 4000 for x in p]
    part2 = [np.cos(x / np.sqrt(i + 1)) for i, x in enumerate(p)]
    return np.sum(part1) - np.prod(part2) + 1


def test_griewank(col_vec: np.ndarray):
    print("Shape:{},val:{}".format(col_vec.shape, griewank(col_vec)))


if __name__ == '__main__':
    x = np.zeros((1, 30))
    test_griewank(col_vec=x)
