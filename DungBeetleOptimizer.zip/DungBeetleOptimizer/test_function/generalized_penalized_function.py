"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:generalized_penalized_function.py
@Created Time: 2023.04.23
"""
import numpy as np


def u_fun(x: np.ndarray, a, k, m):
    u = np.zeros((1, x.shape[1]))
    for i in range(0, x.shape[1]):
        if x[0, i] > a:
            u[0, i] = k * ((x[0, i] - a) ** m)
        elif x[0, i] < -a:
            u[0, i] = k * ((-x[0, i] - a) ** m)
        else:
            u[0, i] = 0
    return u


def generalized_penalized_function(x: np.ndarray):
    """
    [-1,...,-1] 处取全局最小值 0(1.570544771786639e-32)
    :param x:
    :return:
    """
    dim = x.shape[1]
    y_i = 1 + ((x[0, :] + 1) / 4).reshape(1, dim)

    term_1 = 10 * (np.sin(np.pi * y_i[0,0]) ** 2)
    term_2 = 0
    for i in range(0, dim - 1):
        a = (y_i[0, i] - 1) ** 2
        b = 1 + 10 * (np.sin(np.pi * y_i[0, i + 1]) ** 2)
        term_2 += (a * b)

    term_3 = (y_i[0,dim-1] - 1) ** 2

    sum_1 = (np.pi / dim) * (term_1 + term_2 + term_3)
    sum_2 = np.sum(u_fun(x, 10, 100, 4))
    res = sum_1 + sum_2
    return res


if __name__ == '__main__':
    _x = np.full((1, 30), fill_value=-1)
    print(generalized_penalized_function(_x))
