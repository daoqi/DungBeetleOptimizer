"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:criteria_util.py
@Created Time: 2023.04.17
"""
import math

import numpy as np


class Criteria:
    def __init__(self, result_list):
        self.__result_list = result_list
        self.__num = len(result_list)

    def calculate_mean(self):
        return sum(self.__result_list) / self.__num

    def calculate_standard_deviation(self):
        mean = self.calculate_mean()
        temp_res = 0
        for elem in self.__result_list:
            temp_res += (elem - mean) ** 2
        if self.__num > 1:
            return math.sqrt((1 / (self.__num - 1)) * temp_res)
        else:
            return math.sqrt(temp_res)

    @staticmethod
    def calc_one_exp_mean(opt_curve):
        if isinstance(opt_curve, np.ndarray):
            if opt_curve.shape[1] == 1:
                return sum(opt_curve.ravel().tolist()) / opt_curve.shape[0]
        elif isinstance(opt_curve, list):
            return sum(opt_curve) / len(opt_curve)

    @staticmethod
    def calc_one_exp_var(opt_curve):
        if isinstance(opt_curve, np.ndarray):
            if opt_curve.shape[1] == 1:
                return np.var(opt_curve)
        elif isinstance(opt_curve, list):
            return np.var(opt_curve)

