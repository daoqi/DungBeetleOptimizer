"""
@Author: Zheng Wang
@software: comparison_between_dbo.py
@file:patent_tool.py
@Created Time: 2023.08.30
"""
import numpy as np
import os
from task_allocation.data_parser import parser_data

w_d, t_d = parser_data(case_path=os.path.join("../task_allocation_dataset", "case_1_6.txt"))

print(w_d)
print(t_d)


def calc_cost(allocation_method: list):
    etc_list = []
    pc_list = []
    dc = np.std([len(elem) for elem in allocation_method])
    for index, elem in enumerate(allocation_method):
        server_id = index + 1
        etc = 0
        pc = 0
        if len(elem) == 0:
            etc_list.append(0)
            pc_list.append(0)
        else:
            for task_index,task_id in enumerate(elem):
                vertex_num = t_d[task_id][0]
                edge_num = t_d[task_id][1]
                priority = t_d[task_id][2]
                etc += (0.5 * vertex_num + 0.5 * edge_num)
                pc += (priority * task_index)
            pc_list.append(pc)
            etc_list.append(etc/w_d[server_id])
    print(f"etc_list: {etc_list},pc_list:{pc_list},dc:{dc}")
    cost = np.max(np.array(etc_list) + np.array(pc_list) + dc)
    print(f"cost: {cost}")


calc_cost([[1, 10], [9,6,5,4,3], [2,7,8]])
calc_cost([[], [], [7,10,5,8,6,4,1,3,2,9]])
calc_cost([[7,9,10], [6,2,5,8], [1,4,3]])
