"""
@Author: Zheng Wang
@software: DungBeetleOptimizer
@file:__init__.py.py
@Created Time: 2023.04.17
"""
from .criteria import Criteria
